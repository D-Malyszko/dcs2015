﻿/*****************************************************************************
 * 
 * ReoGrid - .NET Spreadsheet Control
 * 
 * http://reogrid.net/
 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
 * KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
 * PURPOSE.
 *
 * ReoGridEditor released under BSD license.
 * 
 * Author: Jing Lu <lujing at unvell.com>
 * Copyright (c) 2012-2015 unvell.com, all rights reserved.
 * 
 ****************************************************************************/

namespace unvell.ReoGrid.Editor
{
	partial class HeaderPropertyDialog
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.txtHeaderText = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.btnOK = new System.Windows.Forms.Button();
			this.btnCancel = new System.Windows.Forms.Button();
			this.labCellBody = new System.Windows.Forms.Label();
			this.cmbCellBody = new System.Windows.Forms.ComboBox();
			this.labRowHeaderWidth = new System.Windows.Forms.Label();
			this.numRowHeaderWidth = new System.Windows.Forms.NumericUpDown();
			this.colorComboBox1 = new unvell.UIControls.ColorComboBox();
			((System.ComponentModel.ISupportInitialize)(this.numRowHeaderWidth)).BeginInit();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(72, 21);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(31, 13);
			this.label1.TabIndex = 0;
			this.label1.Text = "Text:";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBox1
			// 
			this.txtHeaderText.Location = new System.Drawing.Point(117, 18);
			this.txtHeaderText.Name = "textBox1";
			this.txtHeaderText.Size = new System.Drawing.Size(188, 20);
			this.txtHeaderText.TabIndex = 1;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(45, 52);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(58, 13);
			this.label2.TabIndex = 2;
			this.label2.Text = "Text Color:";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// btnOK
			// 
			this.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.btnOK.Location = new System.Drawing.Point(159, 143);
			this.btnOK.Name = "btnOK";
			this.btnOK.Size = new System.Drawing.Size(75, 23);
			this.btnOK.TabIndex = 8;
			this.btnOK.Text = "OK";
			this.btnOK.UseVisualStyleBackColor = true;
			this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
			// 
			// btnCancel
			// 
			this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnCancel.Location = new System.Drawing.Point(240, 143);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(75, 23);
			this.btnCancel.TabIndex = 9;
			this.btnCancel.Text = "Cancel";
			this.btnCancel.UseVisualStyleBackColor = true;
			// 
			// labCellBody
			// 
			this.labCellBody.AutoSize = true;
			this.labCellBody.Location = new System.Drawing.Point(12, 82);
			this.labCellBody.Name = "labCellBody";
			this.labCellBody.Size = new System.Drawing.Size(91, 13);
			this.labCellBody.TabIndex = 4;
			this.labCellBody.Text = "Default Cell Body:";
			this.labCellBody.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// cmbCellBody
			// 
			this.cmbCellBody.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbCellBody.FormattingEnabled = true;
			this.cmbCellBody.Location = new System.Drawing.Point(117, 78);
			this.cmbCellBody.Name = "cmbCellBody";
			this.cmbCellBody.Size = new System.Drawing.Size(188, 21);
			this.cmbCellBody.TabIndex = 5;
			// 
			// labRowHeaderWidth
			// 
			this.labRowHeaderWidth.AutoSize = true;
			this.labRowHeaderWidth.Location = new System.Drawing.Point(35, 82);
			this.labRowHeaderWidth.Name = "labRowHeaderWidth";
			this.labRowHeaderWidth.Size = new System.Drawing.Size(68, 13);
			this.labRowHeaderWidth.TabIndex = 6;
			this.labRowHeaderWidth.Text = "Panel Width:";
			this.labRowHeaderWidth.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// numRowHeaderWidth
			// 
			this.numRowHeaderWidth.Location = new System.Drawing.Point(117, 79);
			this.numRowHeaderWidth.Name = "numRowHeaderWidth";
			this.numRowHeaderWidth.Size = new System.Drawing.Size(74, 20);
			this.numRowHeaderWidth.TabIndex = 7;
			// 
			// colorComboBox1
			// 
			this.colorComboBox1.BackColor = System.Drawing.Color.White;
			this.colorComboBox1.CloseOnClick = true;
			this.colorComboBox1.dropdown = false;
			this.colorComboBox1.Location = new System.Drawing.Point(117, 47);
			this.colorComboBox1.Name = "colorComboBox1";
			this.colorComboBox1.Size = new System.Drawing.Size(188, 23);
			this.colorComboBox1.SolidColor = System.Drawing.Color.Empty;
			this.colorComboBox1.TabIndex = 3;
			this.colorComboBox1.Text = "colorComboBox1";
			// 
			// HeaderPropertyForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.CancelButton = this.btnCancel;
			this.ClientSize = new System.Drawing.Size(334, 181);
			this.Controls.Add(this.numRowHeaderWidth);
			this.Controls.Add(this.labRowHeaderWidth);
			this.Controls.Add(this.cmbCellBody);
			this.Controls.Add(this.labCellBody);
			this.Controls.Add(this.btnCancel);
			this.Controls.Add(this.btnOK);
			this.Controls.Add(this.colorComboBox1);
			this.Controls.Add(this.txtHeaderText);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "HeaderPropertyForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Header Properties";
			((System.ComponentModel.ISupportInitialize)(this.numRowHeaderWidth)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox txtHeaderText;
		private UIControls.ColorComboBox colorComboBox1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button btnOK;
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.Label labCellBody;
		private System.Windows.Forms.ComboBox cmbCellBody;
		private System.Windows.Forms.Label labRowHeaderWidth;
		private System.Windows.Forms.NumericUpDown numRowHeaderWidth;
	}
}
﻿/*****************************************************************************
 * 
 * ReoGrid - .NET Spreadsheet Control
 * 
 * http://reogrid.net
 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
 * KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
 * PURPOSE.
 *
 * ReoGrid Demo project released under BSD license.
 * 
 * Author: Jing Lu <lujing at unvell.com>
 * Copyright (c) 2012-2015 unvell.com, all rights reserved.
 * 
 ****************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using unvell.ReoGrid.Actions;

namespace unvell.ReoGrid.Demo.Features
{
	public partial class SetEditableRangeForm : Form
	{
		public SetEditableRangeForm()
		{
			InitializeComponent();
		}

		private void btnSetEditableRange_Click(object sender, EventArgs ee)
		{
			var editableRange = new ReoGridRange(3, 1, 2, 3);

			var worksheet = grid.CurrentWorksheet;

			worksheet.SetRangeBorders(editableRange, BorderPositions.Outside, BorderStyle.BlackSolid);

			worksheet[2, 1] = "Edit only be allowed in this range:";
			worksheet.BeforeCellEdit += (s, e) => e.IsCancelled = !editableRange.Contains(e.Cell.Position);
		}

	}
}

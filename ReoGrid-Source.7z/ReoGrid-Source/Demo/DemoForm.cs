﻿/*****************************************************************************
 * 
 * ReoGrid - .NET Spreadsheet Control
 * 
 * http://reogrid.net
 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
 * KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
 * PURPOSE.
 *
 * ReoGrid Demo project released under BSD license.
 * 
 * Author: Jing Lu <lujing at unvell.com>
 * Copyright (c) 2012-2015 unvell.com, all rights reserved.
 * 
 ****************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;
using unvell.Common;
using unvell.ReoGrid.Demo.CustomCells;
using unvell.ReoGrid.Demo.Data;
using unvell.ReoGrid.Demo.Features;
using unvell.ReoGrid.Demo.Formula;
using unvell.ReoGrid.Demo.Other;
using unvell.ReoGrid.Demo.Print;
using unvell.ReoGrid.Demo.Scripts;
using unvell.ReoGrid.Demo.Styles;
using unvell.ReoGrid.Editor;

namespace unvell.ReoGrid.Demo
{
	public partial class DemoForm : Form
	{
		public DemoForm()
		{
			InitializeComponent();
		}


        public void LoadMainForm()
        {

         			try
			{





				Cursor = Cursors.Default;
				new ReoGridEditor().Show();
			}
			finally
			{
				Cursor = Cursors.Default;
			}
		



        }

		private void DemoForm_Load(object sender, EventArgs e)
		{
			labVersion.Text = "version " + ProductVersion.ToString();
		}

		/// <summary>
		/// For speed up the demo running, this method will be executed after 
		/// demo form is shown, a dummy instance of grid control is created 
		/// once and something dummy operations performed in memory.
		/// </summary>
		private static void Preload()
		{
			// do something dummy operations to speed up the first time of loading grid control
			try
			{
				Cursor.Current = Cursors.AppStarting;

				// object preload = ResourcePoolManager.Instance;
				object preload = unvell.ReoGrid.Rendering.BorderPainter.Instance;

				// initialize dummy editor
				ReoGridEditor editor = new ReoGridEditor();

				// run a dummy script 
				editor.GridControl.RunScript("eval(true);");

				// force control to do rendering once
				var bmp = editor.CurrentWorksheet.DrawToBitmap(640, 480);
				bmp.Dispose();

				// release editor and grid control
				editor.Dispose();
				editor.GridControl.Dispose();
			}
			finally
			{
				Cursor.Current = Cursors.Default;
			}
		}

		protected override void OnShown(EventArgs e)
		{
			base.OnShown(e);

			try
			{
				// async-preload 
				((Action)Preload).BeginInvoke(null, null);
			}
			catch { }
		}

		private static Random rand;

		/// <summary>
		/// randomly select a button to perform a demo
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void randomDemoToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (rand == null) rand = new Random();

			Button btn = null;
			Control container = this;

			while (true)
			{
				int index = rand.Next(container.Controls.Count);
				Control ctl = container.Controls[index];

				if (ctl is GroupBox)
				{
					container = (Control)ctl;
				}
				else if (ctl is Button)
				{
					btn = (Button)ctl;
					break;
				}

			}

			btn.PerformClick();
		}

		private void button2_Click(object sender, EventArgs e)
		{
			Open("order_sample.rgf");
		}

		private void Open(string filename)
		{
			try
			{
				Cursor = Cursors.WaitCursor;

				using (ReoGridEditor editor = new ReoGridEditor())
				{
#if DEBUG
					editor.CurrentFilePath = System.IO.Path.Combine("..\\..\\..\\Samples\\", filename);
#else
					editor.CurrentFilePath = filename;
#endif
					editor.ShowDialog();
				}
			}
			finally
			{
				Cursor = Cursors.Default;
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			Open("calendar_2008_1.rgf");
		}

		private void button3_Click(object sender, EventArgs e)
		{
			Open("project_cost_summary.rgf");
		}

		private void button4_Click(object sender, EventArgs e)
		{
			using (GridForm gf = new GridForm())
			{
				gf.Open("calendar_2013.rgf", (grid) =>
				{
					grid.SetSettings(WorksheetSettings.View_ShowRowHeader | WorksheetSettings.View_ShowColumnHeader, false);
					grid.SetSettings(WorksheetSettings.Edit_Readonly, true);

					grid.SelectionMode = ReoGridSelectionMode.Cell;
				});

				gf.ShowDialog();
			}
		}

		private void button5_Click(object sender, EventArgs e)
		{
			Open("Financial_Ratios.rgf");
		}

		private void button6_Click(object sender, EventArgs e)
		{
			Open("background_color_patterns.rgf");
		}

		private void button7_Click(object sender, EventArgs e)
		{
			//Open("border_styles.rgf");
			using (var f = new BorderStylesForm()) f.ShowDialog();
		}

		private void button8_Click(object sender, EventArgs e)
		{
			Open("merged_range.rgf");
		}

		private void button9_Click(object sender, EventArgs e)
		{
			Open("Maze.rgf");
		}

		private void button10_Click(object sender, EventArgs e)
		{
			Open("cell_format.rgf");
		}

		private void button14_Click(object sender, EventArgs e)
		{
			using (var f = new OnlyNumberInputForm()) f.ShowDialog();
		}

		private void button15_Click(object sender, EventArgs e)
		{
			Open("change_colors.rgf");
		}

		private void btnMergeCells_Click(object sender, EventArgs e)
		{
			using (var f = new MergeCellsForm()) f.ShowDialog();
		}

		private void button16_Click(object sender, EventArgs e)
		{
			using (var f = new SetEditableRangeForm()) f.ShowDialog();
		}

		private void button18_Click(object sender, EventArgs e)
		{
			using (var f = new RunScriptForm()) f.ShowDialog();
		}

		private void button21_Click(object sender, EventArgs e)
		{
			using (var f = new PickRangeForm()) f.ShowDialog();
		}

		private void button19_Click(object sender, EventArgs e)
		{
			using (var f = new ClipboardEventForm()) f.ShowDialog();
		}

		private void button17_Click(object sender, EventArgs e)
		{
			using (var f = new HandleEventsForm()) f.ShowDialog();
		}

		private void button20_Click(object sender, EventArgs e)
		{
			using (var f = new DataFormatForm()) f.ShowDialog();
		}

		private void projectHomepageToolStripMenuItem_Click(object sender, EventArgs e)
		{
			Process.Start("http://reogrid.net/");
		}

		private void button23_Click(object sender, EventArgs e)
		{
			using (var f = new ZoomForm()) f.ShowDialog();
		}

		private void button22_Click(object sender, EventArgs e)
		{
			try
			{
				Cursor = Cursors.Default;
				new ReoGridEditor().Show();
			}
			finally
			{
				Cursor = Cursors.Default;
			}
		}

		private void button24_Click(object sender, EventArgs e)
		{
			using (var f = new CustomizeFunctionForm()) f.ShowDialog();
		}

		private void button25_Click(object sender, EventArgs e)
		{
			using (ReoGridEditor editor = new ReoGridEditor())
			{
				editor.GridControl.Script =
@"// Joke sample: reoquery

function reo(cell) {
  this.cell = cell;
  
  this.val = function(str) { 
    if(__args__.length == 0) {
      return this.cell.data;
    } else {
      this.cell.data = str;
      return this;
    }
  };
  
  this.style = function(key, value) {
    if (__args__.length == 1) {
      return this.cell.style[key];
    } else {
      this.cell.style[key] = value;
      return this;
    }
  };
}

script.$ = function(r, c) {
  var sheet = workbook.currentWorksheet;

  return new reo(c == null ? sheet.getCell(r) : sheet.getCell(r, c));
};

// call like jQuery
$('B4').val('hello').style('backgroundColor', 'yellow');
$(3, 2).val('world!').style('backgroundColor', 'lightgreen');


";
				editor.CurrentWorksheet[1, 1] = "See the script editor!";
				editor.NewDocumentOnLoad = false;
				editor.ShowDialog();
			}
		}

		private void button26_Click(object sender, EventArgs e)
		{
			using (var f = new CellsEventForm()) f.ShowDialog();
		}

		private void button27_Click(object sender, EventArgs e)
		{
			customCellsContextMenuStrip.Show(button27, new Point(0, button27.Height));
		}

		private void numericProgressToolStripMenuItem_Click(object sender, EventArgs e)
		{
			using (var f = new NumericProgressForm()) f.ShowDialog();
		}

		private void slideCellToolStripMenuItem_Click(object sender, EventArgs e)
		{
			using (var f = new SlideCellForm()) f.ShowDialog();
		}

		private void dropdownButton1_Click(object sender, EventArgs e)
		{
			controlAppearanceContextMenuStrip.Show(dropdownButton1, new Point(0, dropdownButton1.Height));
		}

		private void goldSilverToolStripMenuItem_Click(object sender, EventArgs e)
		{
			using (ReoGridEditor editor = new ReoGridEditor())
			{
				ReoGridControlStyle rgcs = new ReoGridControlStyle(Color.White, Color.DarkOrange, false);
				rgcs.SetColor(ReoGridControlColors.GridBackground, Color.DimGray);
				rgcs.SetColor(ReoGridControlColors.GridLine, Color.Gray);
				editor.GridControl.ControlStyle = rgcs;
				editor.ShowDialog();
			}
		}

		private void lightGreenToolStripMenuItem_Click(object sender, EventArgs e)
		{
			using (ReoGridEditor editor = new ReoGridEditor())
			{
				ReoGridControlStyle rgcs = new ReoGridControlStyle(Color.LightGreen, Color.White, false);
				rgcs.SetColor(ReoGridControlColors.SelectionBorder, Color.Green);
				rgcs.SetColor(ReoGridControlColors.SelectionFill, Color.FromArgb(30, Color.Green));
				rgcs.SetColor(ReoGridControlColors.GridLine, Color.FromArgb(200, 255, 200));
				rgcs.SetColor(ReoGridControlColors.GridBackground, Color.White);
				editor.GridControl.ControlStyle = rgcs;

				editor.ShowDialog();
			}
		}

		private void snowWhiteToolStripMenuItem_Click(object sender, EventArgs e)
		{
			using (ReoGridEditor editor = new ReoGridEditor())
			{
				ReoGridControlStyle rgcs = new ReoGridControlStyle(Color.LightSkyBlue, Color.White, false);
				rgcs.SetColor(ReoGridControlColors.SelectionBorder, Color.SkyBlue);
				rgcs.SetColor(ReoGridControlColors.SelectionFill, Color.FromArgb(30, Color.Blue));
				rgcs.SetColor(ReoGridControlColors.GridLine, Color.FromArgb(220, 220, 255));
				rgcs.SetColor(ReoGridControlColors.GridBackground, Color.White);
				editor.GridControl.ControlStyle = rgcs;

				editor.ShowDialog();
			}
		}

		private void button11_Click(object sender, EventArgs e)
		{
			using (var f = new ManyRowTestForm()) f.ShowDialog();
		}

		private void button13_Click(object sender, EventArgs e)
		{
			Open("outline.rgf");
		}

		private void reportBugToolStripMenuItem_Click(object sender, EventArgs e)
		{
			Process.Start("http://reogrid.net/support");
		}
			
		private void lnkReportBug_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			Process.Start("http://reogrid.net/support");
		}	

		private void button29_Click(object sender, EventArgs e)
		{
			using (var f = new BuiltInTypesForm()) f.ShowDialog();
		}

		private void button30_Click(object sender, EventArgs e)
		{
			using (var f = new OutlineWithFreezeForm()) f.ShowDialog();
		}

		private void button31_Click(object sender, EventArgs e)
		{
			using (var f = new AnimationCellForm()) f.ShowDialog();
		}

		private void button12_Click(object sender, EventArgs e)
		{

		}

		private void button28_Click(object sender, EventArgs e)
		{

		}

		private void button32_Click(object sender, EventArgs e)
		{
			using (var f = new MaximumGridForm()) f.ShowDialog();
		}

		private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
		{
			new AboutForm().ShowDialog();
		}

		private void button33_Click(object sender, EventArgs e)
		{
			using (var f = new NumericProgressForm()) f.ShowDialog();
		}

		private void button34_Click(object sender, EventArgs e)
		{
			using (var f = new SlideCellForm()) f.ShowDialog();
		}

		private void ShowEmptyGridForm(int rows, int cols, Action<Worksheet> gridInitializer)
		{
			using (GridForm gf = new GridForm())
			{
				gf.PostHandler = worksheet =>
				{
					worksheet.Resize(rows, cols);
					gridInitializer(worksheet);
				};

				gf.ShowDialog();
			}
		}

		private void btnFreezeToEdges_Click(object sender, EventArgs e)
		{
			freezeToEdgesContextMenuStrip.Show(btnFreezeToEdges, new Point(0, btnFreezeToEdges.Height));
		}

		private void freeToLeftToolStripMenuItem_Click(object sender, EventArgs e)
		{
			ShowEmptyGridForm(100, 30, worksheet =>
			{
				worksheet.FreezeToCell(0, 5, FreezePosition.Left);
				worksheet[5, 1] = "frozen region";
				worksheet[5, 7] = "active region";
			});
		}

		private void freezeToTopToolStripMenuItem_Click(object sender, EventArgs e)
		{
			ShowEmptyGridForm(100, 30, worksheet =>
			{
				worksheet.FreezeToCell(10, 0, FreezePosition.Top);
				worksheet[5, 5] = "frozen region";
				worksheet[12, 5] = "active region";
			});
		}

		private void freezeToRightToolStripMenuItem_Click(object sender, EventArgs e)
		{
			ShowEmptyGridForm(100, 30, worksheet =>
			{
				worksheet.FreezeToCell(0, 25, FreezePosition.Right);
				worksheet[5, 27] = "frozen region";
				worksheet[5, 7] = "active region";
			});
		}

		private void freezeToBottomToolStripMenuItem_Click(object sender, EventArgs e)
		{
			ShowEmptyGridForm(100, 30, worksheet =>
			{
				worksheet.FreezeToCell(85, 0, FreezePosition.Bottom);
				worksheet[90, 5] = "frozen region";
				worksheet[12, 5] = "active region";
			});
		}

		private void freezeToLeftTopToolStripMenuItem_Click(object sender, EventArgs e)
		{
			ShowEmptyGridForm(100, 30, worksheet =>
			{
				worksheet.FreezeToCell(10, 5, FreezePosition.LeftTop);
				worksheet[5, 1] = "frozen region";
				worksheet[15, 7] = "active region";
			});
		}

		private void freezeToLeftBottomToolStripMenuItem_Click(object sender, EventArgs e)
		{
			ShowEmptyGridForm(100, 30, worksheet =>
			{
				worksheet.FreezeToCell(85, 5, FreezePosition.LeftBottom);
				worksheet[90, 2] = "frozen region";
				worksheet[5, 7] = "active region";
			});
		}

		private void freezeToRightTopToolStripMenuItem_Click(object sender, EventArgs e)
		{
			ShowEmptyGridForm(100, 30, worksheet =>
			{
				worksheet.FreezeToCell(10, 25, FreezePosition.RightTop);
				worksheet[5, 27] = "frozen region";
				worksheet[15, 3] = "active region";
			});
		}

		private void freezeToRightBottomToolStripMenuItem_Click(object sender, EventArgs e)
		{
			ShowEmptyGridForm(100, 30, worksheet =>
			{
				worksheet.FreezeToCell(85, 25, FreezePosition.RightBottom);
				worksheet[90, 27] = "frozen region";
				worksheet[5, 3] = "active region";
			});
		}

		private void btnCustomHeader_Click(object sender, EventArgs e)
		{
			using (var f = new CustomHeaderForm()) f.ShowDialog();
		}

		private void btnSelectionMode_Click(object sender, EventArgs e)
		{
			using (var f = new SelectionModeForm()) f.ShowDialog();
		}

		private void button38_Click(object sender, EventArgs e)
		{
			using (var f = new FormulaForm()) f.ShowDialog();
		}

		private void button35_Click(object sender, EventArgs e)
		{
			using (var f = new NamedRangeReferenceForm()) f.ShowDialog();
		}

		private void closeToolStripMenuItem_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void button2_Click_1(object sender, EventArgs e)
		{
			using (var f = new PrintPreviewDemoForm()) f.ShowDialog();
		}

		private void btnFilterAndSort_Click(object sender, EventArgs e)
		{
			using (GridForm gf = new GridForm())
			{
				gf.Open("zip_code_sample.csv", (grid) =>
				{
					grid.CreateColumnFilter("A", "O");
				});

				gf.ShowDialog();
			}
		}

		private void btnLoadExcel_Click(object sender, EventArgs e)
		{
			using (var ofd = new OpenFileDialog())
			{
				ofd.Filter = "Excel 2007 Document(*.xlsx)|*.xlsx|All files(*.*)|*.*";
				if (ofd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
				{
					using (GridForm gf = new GridForm())
					{
						gf.Open(ofd.FileName);
						gf.ShowDialog();
					}
				}
			}
		}

		private void btnMultisheet_Click(object sender, EventArgs e)
		{
			using (var f = new MultisheetForm()) f.ShowDialog();
		}

		private void btnCustomDropdown_Click(object sender, EventArgs e)
		{
			using (var f = new CustomDropdownForm()) f.ShowDialog();

		}

		private void btnCustomSelection_Click(object sender, EventArgs e)
		{
			using (var f = new CustomSelectionForm()) f.ShowDialog();
		}
	}
}

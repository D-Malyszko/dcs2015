﻿/*****************************************************************************
 * 
 * ReoGrid - .NET Spreadsheet Control
 * 
 * http://reogrid.net/
 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
 * KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
 * PURPOSE.
 *
 * ReoGridEditor released under BSD license.
 * 
 * Author: Jing Lu <lujing at unvell.com>
 * Copyright (c) 2012-2015 unvell.com, all rights reserved.
 * 
 ****************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using unvell.ReoGrid.CellTypes;

namespace unvell.ReoGrid.Editor
{
	internal partial class HeaderPropertyDialog : Form
	{
		public RowOrColumn RowOrColumn { get; set; }

		public string HeaderText { get; set; }

		public Color HeaderTextColor { get; set; }

		public Type DefaultCellBody { get; set; }

		public int RowHeaderWidth { get; set; }

		public HeaderPropertyDialog(RowOrColumn rowOrColumn)
		{
			this.RowOrColumn = rowOrColumn;

			InitializeComponent();

			if (this.RowOrColumn == ReoGrid.RowOrColumn.Column)
			{
				this.cmbCellBody.Items.Add("(null)");

				foreach (var cellType in CellTypesManager.AvailableCellTypes)
				{
					var name = cellType.Name;
					if (name.EndsWith("Cell")) name = name.Substring(0, name.Length - 4);

					cmbCellBody.Items.Add(new CellBodyItem
											{
												Type = cellType,
												Name = name,
											});
				}
				
				labCellBody.Visible = cmbCellBody.Visible = cmbCellBody.Enabled = true;
				labRowHeaderWidth.Visible = numRowHeaderWidth.Visible = numRowHeaderWidth.Enabled = false;
			}
			else
			{
				labCellBody.Visible = cmbCellBody.Visible = cmbCellBody.Enabled = false;
				labRowHeaderWidth.Visible = numRowHeaderWidth.Visible = numRowHeaderWidth.Enabled = true;
			}

			this.txtHeaderText.KeyDown += (s, e) =>
			{
				if (e.KeyCode == Keys.Enter) btnOK.PerformClick();
			};
		}

		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad(e);

			this.txtHeaderText.Text = HeaderText;
			this.colorComboBox1.SolidColor = HeaderTextColor;
			this.numRowHeaderWidth.Value = RowHeaderWidth;

			if (this.DefaultCellBody != null)
			{
				for (int i = 0; i < this.cmbCellBody.Items.Count; i++)
				{
					if (this.DefaultCellBody == this.cmbCellBody.Items[i])
					{
						this.cmbCellBody.SelectedIndex = i;
						break;
					}
				}
			}
			else if (this.cmbCellBody.Items.Count > 0)
			{
				this.cmbCellBody.SelectedIndex = 0;
			}
		}

		private class CellBodyItem
		{
			public Type Type { get; set; }

			public string Name { get; set; }

			public override string ToString()
			{
				return this.Name;
			}
		}

		private void btnOK_Click(object sender, EventArgs e)
		{
			this.Text = (this.RowOrColumn == ReoGrid.RowOrColumn.Row ? "Row" : "Column") + " Header Properties";

			HeaderText = txtHeaderText.Text;
			HeaderTextColor = colorComboBox1.SolidColor;
			RowHeaderWidth = (int)numRowHeaderWidth.Value;

			DefaultCellBody = (cmbCellBody.SelectedItem == null || cmbCellBody.SelectedIndex <= 0) ? null :
				((CellBodyItem)cmbCellBody.SelectedItem).Type;
		}
	}
}

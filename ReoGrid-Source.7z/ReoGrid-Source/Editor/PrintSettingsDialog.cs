﻿/*****************************************************************************
 * 
 * ReoGrid - .NET Spreadsheet Control
 * 
 * http://reogrid.net/
 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
 * KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
 * PURPOSE.
 *
 * ReoGridEditor released under BSD license.
 * 
 * Author: Jing Lu <lujing at unvell.com>
 * Copyright (c) 2012-2015 unvell.com, all rights reserved.
 * 
 ****************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using unvell.ReoGrid.Print;

namespace unvell.ReoGrid.Editor
{
	internal partial class PrintSettingsDialog : Form
	{
		public PageSettings PageSettings { get; set; }

		public ReoGridPrintSettings PrintSettings { get; set; }

		public PrintSettingsDialog()
		{
			InitializeComponent();
		}

		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad(e);

			if (this.PageSettings == null)
			{
				btnPaperSetup.Enabled = false;
			}
			else
			{
				btnPaperSetup.Enabled = true;
				UpdatePaperInformation();
			}

			this.numScale.Value = (decimal)(this.PrintSettings.PageScaling * 100f);
			
			rdoDownThenOver.Checked = this.PrintSettings.PageOrder == PrintPageOrder.DownThenOver;
			rdoOverThenDown.Checked = this.PrintSettings.PageOrder == PrintPageOrder.OverThenDown;
		}

		private void btnPaperSetup_Click(object sender, EventArgs e)
		{
			using (PageSetupDialog psd = new PageSetupDialog())
			{
				psd.PageSettings = this.PageSettings;

				psd.AllowMargins = true;
				psd.AllowPrinter = true;
				psd.AllowPaper = true;
				psd.EnableMetric = true;

				if (psd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
				{
					UpdatePaperInformation();
				}
			}
		}

		private void UpdatePaperInformation()
		{
			if (this.PageSettings.Landscape)
			{
				txtPaperSize.Text = string.Format("{0} ({1} x {2})", this.PageSettings.PaperSize.PaperName,
					this.PageSettings.PaperSize.Width, this.PageSettings.PaperSize.Height);
			}
			else
			{
				txtPaperSize.Text = string.Format("{0} ({1} x {2})", this.PageSettings.PaperSize.PaperName,
					this.PageSettings.PaperSize.Height, this.PageSettings.PaperSize.Width);
			}

			txtPaperOrientation.Text = this.PageSettings.Landscape ? "Landscape" : "Portrait";
		}

		private void btnOK_Click(object sender, EventArgs e)
		{
			this.PrintSettings.PageScaling = (float)numScale.Value / 100f;
			this.PrintSettings.PageOrder = rdoDownThenOver.Checked ? PrintPageOrder.DownThenOver : PrintPageOrder.OverThenDown;
		}
	}
}

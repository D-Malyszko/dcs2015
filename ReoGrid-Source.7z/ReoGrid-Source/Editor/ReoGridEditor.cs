﻿/*****************************************************************************
 * 
 * ReoGrid - .NET Spreadsheet Control
 * 
 * http://reogrid.net/
 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
 * KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
 * PURPOSE.
 *
 * ReoGridEditor released under BSD license.
 * 
 * Author: Jing Lu <lujing at unvell.com>
 * Copyright (c) 2012-2015 unvell.com, all rights reserved.
 * 
 ****************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
using System.IO;
using System.Diagnostics;
using System.Drawing.Printing;

using unvell.Common;

using unvell.ReoGrid.Editor.Properties;
using unvell.ReoGrid.PropertyPages;
using unvell.ReoGrid.Actions;
using unvell.ReoGrid.CellTypes;
using unvell.ReoGrid.Events;
using unvell.ReoGrid.Data;
using unvell.ReoGrid.Print;
using unvell.ReoGrid.WinForm;
using unvell.ReoGrid.IO;

#if EX_SCRIPT
using unvell.ReoScript.Editor;
using unvell.ReoScript;
#endif

namespace unvell.ReoGrid.Editor
{
	public partial class ReoGridEditor : Form
	{
		#region Constructor

		private NamedRangeManageForm nameManagerForm = null;

		/// <summary>
		/// Construct ReoGrid Control.
		/// </summary>
		public ReoGridEditor()
		{
			InitializeComponent();

			NewDocumentOnLoad = true;

			SuspendLayout();
			isUIUpdating = true;

			fontToolStripComboBox.Text = Worksheet.DefaultStyle.FontName;

			fontSizeToolStripComboBox.Text = Worksheet.DefaultStyle.FontSize.ToString();
			fontSizeToolStripComboBox.Items.AddRange(FontUIToolkit.FontSizeList.Select(f => (object)f).ToArray());

			backColorPickerToolStripButton.CloseOnClick = true;
			borderColorPickToolStripItem.CloseOnClick = true;
			textColorPickToolStripItem.CloseOnClick = true;

			zoomToolStripDropDownButton.Text = "100%";

			isUIUpdating = false;

			toolbarToolStripMenuItem.Click += (s, e) => fontToolStrip.Visible = toolStrip1.Visible = toolbarToolStripMenuItem.Checked;
			formulaBarToolStripMenuItem.CheckedChanged += (s, e) => formulaBar.Visible = formulaBarToolStripMenuItem.Checked;
			statusBarToolStripMenuItem.CheckedChanged += (s, e) => statusStrip1.Visible = statusBarToolStripMenuItem.Checked;
			sheetSwitcherToolStripMenuItem.CheckedChanged += (s, e) =>
				this.grid.SetSettings(WorkbookSettings.View_ShowSheetTabControl, sheetSwitcherToolStripMenuItem.Checked);

			showHorizontaScrolllToolStripMenuItem.CheckedChanged += (s, e) =>
				this.grid.SetSettings(WorkbookSettings.View_ShowHorScroll, showHorizontaScrolllToolStripMenuItem.Checked);
			showVerticalScrollbarToolStripMenuItem.CheckedChanged += (s, e) =>
				this.grid.SetSettings(WorkbookSettings.View_ShowVerScroll, showVerticalScrollbarToolStripMenuItem.Checked);

			showGridLinesToolStripMenuItem.CheckedChanged += (s, e) =>
				this.CurrentWorksheet.SetSettings(WorksheetSettings.View_ShowGridLine, showGridLinesToolStripMenuItem.Checked);
			showPageBreakToolStripMenuItem.CheckedChanged += (s, e) =>
				this.CurrentWorksheet.SetSettings(WorksheetSettings.View_ShowPageBreaks, showPageBreakToolStripMenuItem.Checked);
			showRowHeaderToolStripMenuItem.CheckedChanged += (s, e) =>
				this.CurrentWorksheet.SetSettings(WorksheetSettings.View_ShowRowHeader, showRowHeaderToolStripMenuItem.Checked);
			showColumnHeaderToolStripMenuItem.CheckedChanged += (s, e) =>
				this.CurrentWorksheet.SetSettings(WorksheetSettings.View_ShowColumnHeader, showColumnHeaderToolStripMenuItem.Checked);
			showRowOutlineToolStripMenuItem.CheckedChanged += (s, e) =>
				this.CurrentWorksheet.SetSettings(WorksheetSettings.View_AllowShowRowOutlines, showRowOutlineToolStripMenuItem.Checked);
			showColumnOutlineToolStripMenuItem.CheckedChanged += (s, e) =>
				this.CurrentWorksheet.SetSettings(WorksheetSettings.View_AllowShowColumnOutlines, showColumnOutlineToolStripMenuItem.Checked);

			sheetReadonlyToolStripMenuItem.CheckedChanged += (s, e) =>
				this.CurrentWorksheet.SetSettings(WorksheetSettings.Edit_Readonly, sheetReadonlyToolStripMenuItem.Checked);

			resetAllPageBreaksToolStripMenuItem.Click += (s, e) => this.CurrentWorksheet.ResetAllPageBreaks();
			resetAllPageBreaksToolStripMenuItem1.Click += (s, e) => this.CurrentWorksheet.ResetAllPageBreaks();

			this.grid.WorksheetInserted += (ss, ee) =>
			{
				var worksheet = ee.Worksheet;

				worksheet.SelectionRangeChanged += grid_SelectionRangeChanged;
				worksheet.SelectionModeChanged += worksheet_SelectionModeChanged;
				worksheet.SelectionStyleChanged += worksheet_SelectionModeChanged;
				worksheet.SelectionForwardDirectionChanged += worksheet_SelectionForwardDirectionChanged;
				worksheet.CellsFrozen += UpdateMenuAndToolStripsWhenAction;
				worksheet.Resetted += worksheet_Resetted;
				worksheet.SettingsChanged += worksheet_SettingsChanged;
				worksheet.GridScaled += worksheet_GridScaled;
			};

			this.grid.WorksheetRemoved += (ss, ee) =>
			{
				var worksheet = ee.Worksheet;

				worksheet.SelectionRangeChanged -= grid_SelectionRangeChanged;
				worksheet.SelectionModeChanged -= worksheet_SelectionModeChanged;
				worksheet.SelectionStyleChanged -= worksheet_SelectionModeChanged;
				worksheet.SelectionForwardDirectionChanged -= worksheet_SelectionForwardDirectionChanged;
				worksheet.CellsFrozen -= UpdateMenuAndToolStripsWhenAction;
				worksheet.Resetted -= worksheet_Resetted;
				worksheet.SettingsChanged -= worksheet_SettingsChanged;
				worksheet.GridScaled -= worksheet_GridScaled;
			};

			selModeNoneToolStripMenuItem.Click += (s, e) => this.grid.CurrentWorksheet.SelectionMode = ReoGridSelectionMode.None;
			selModeCellToolStripMenuItem.Click += (s, e) => this.grid.CurrentWorksheet.SelectionMode = ReoGridSelectionMode.Cell;
			selModeRangeToolStripMenuItem.Click += (s, e) => this.grid.CurrentWorksheet.SelectionMode = ReoGridSelectionMode.Range;
			selModeRowToolStripMenuItem.Click += (s, e) => this.grid.CurrentWorksheet.SelectionMode = ReoGridSelectionMode.Row;
			selModeColumnToolStripMenuItem.Click += (s, e) => this.grid.CurrentWorksheet.SelectionMode = ReoGridSelectionMode.Column;

			selStyleNoneToolStripMenuItem.Click += (s, e) => this.grid.CurrentWorksheet.SelectionStyle = ReoGridSelectionStyle.None;
			selStyleDefaultToolStripMenuItem.Click += (s, e) => this.grid.CurrentWorksheet.SelectionStyle = ReoGridSelectionStyle.Default;
			selStyleFocusRectToolStripMenuItem.Click += (s, e) => this.grid.CurrentWorksheet.SelectionStyle = ReoGridSelectionStyle.FocusRect;

			selDirRightToolStripMenuItem.Click += (s, e) => this.grid.CurrentWorksheet.SelectionForwardDirection = SelectionForwardDirection.Right;
			selDirDownToolStripMenuItem.Click += (s, e) => this.grid.CurrentWorksheet.SelectionForwardDirection = SelectionForwardDirection.Down;

			zoomToolStripDropDownButton.TextChanged += zoomToolStripDropDownButton_TextChanged;

			undoToolStripButton.Click += Undo;
			redoToolStripButton.Click += Redo;
			undoToolStripMenuItem.Click += Undo;
			redoToolStripMenuItem.Click += Redo;

			mergeRangeToolStripMenuItem.Click += MergeSelectionRange;
			cellMergeToolStripButton.Click += MergeSelectionRange;
			unmergeRangeToolStripMenuItem.Click += UnmergeSelectionRange;
			unmergeRangeToolStripButton.Click += UnmergeSelectionRange;
			mergeCellsToolStripMenuItem.Click += MergeSelectionRange;
			unmergeCellsToolStripMenuItem.Click += UnmergeSelectionRange;
			formatCellsToolStripMenuItem.Click += formatCellToolStripMenuItem_Click;
			resizeToolStripMenuItem.Click += resizeToolStripMenuItem_Click;
			textWrapToolStripButton.Click += textWrapToolStripButton_Click;

			// todo
			this.grid.ActionPerformed += (s, e) => UpdateMenuAndToolStripsWhenAction(s, e);
			this.grid.Undid += (s, e) => UpdateMenuAndToolStripsWhenAction(s, e);
			this.grid.Redid += (s, e) => UpdateMenuAndToolStripsWhenAction(s, e);

			rowHeightToolStripMenuItem.Click += (s, e) =>
			{
				var worksheet = this.CurrentWorksheet;

				using (SetWidthOrHeightDialog rowHeightForm = new SetWidthOrHeightDialog(ChangeWidthOrHeight.Height))
				{
					rowHeightForm.Value = worksheet.GetRowHeight(worksheet.SelectionRange.Row);
					if (rowHeightForm.ShowDialog() == DialogResult.OK)
					{
						this.grid.DoAction(new SetRowsHeightAction(worksheet.SelectionRange.Row,
							worksheet.SelectionRange.Rows, (ushort)rowHeightForm.Value));
					}
				}
			};

			columnWidthToolStripMenuItem.Click += (s, e) =>
			{
				var worksheet = this.CurrentWorksheet;

				using (SetWidthOrHeightDialog colWidthForm = new SetWidthOrHeightDialog(ChangeWidthOrHeight.Width))
				{
					colWidthForm.Value = worksheet.GetColumnWidth(worksheet.SelectionRange.Col);
					if (colWidthForm.ShowDialog() == DialogResult.OK)
					{
						this.grid.DoAction(new SetColsWidthAction(worksheet.SelectionRange.Col,
							worksheet.SelectionRange.Cols, (ushort)colWidthForm.Value));
					}
				}
			};

			exportAsHtmlToolStripMenuItem.Click += (s, e) =>
			{
				using (SaveFileDialog sfd = new SaveFileDialog())
				{
					sfd.Filter = "HTML File(*.html;*.htm)|*.html;*.htm";
					sfd.FileName = "Exported ReoGrid";

					if (sfd.ShowDialog() == DialogResult.OK)
					{
						using (FileStream fs = new FileStream(sfd.FileName, FileMode.Create))
						{
							this.CurrentWorksheet.ExportAsHTML(fs);
						}

						Process.Start(sfd.FileName);
					}
				}
			};

			editXMLToolStripMenuItem.Click += (s, e) =>
			{
				string filepath = null;

				if (string.IsNullOrEmpty(this.CurrentFilePath))
				{
					if (string.IsNullOrEmpty(currentTempFilePath))
					{
						currentTempFilePath = Path.Combine(Path.GetTempPath(),
							Path.GetFileNameWithoutExtension(Path.GetTempFileName()) + ".txt");
					}
					filepath = currentTempFilePath;
				}
				else if (!this.CurrentFilePath.EndsWith(".rgf")
					&& !this.CurrentFilePath.EndsWith(".xml"))
				{
					MessageBox.Show("Only ReoGrid Format File (.rgf) can edit XML content.");
					return;
				}
				else
				{
					if (MessageBox.Show("Editor will save current file, continue?",
						"Edit XML", MessageBoxButtons.OKCancel, MessageBoxIcon.Question)
						== System.Windows.Forms.DialogResult.Cancel)
					{
						return;
					}

					filepath = this.CurrentFilePath;
				}

				using (var fs = new FileStream(filepath, FileMode.Create, FileAccess.Write))
				{
					this.CurrentWorksheet.Save(fs);
				}

				Process p = Process.Start("notepad.exe", filepath);
				p.WaitForExit();

				if (p.ExitCode == 0)
				{
					this.CurrentWorksheet.Load(filepath);
				}
			};

			saveToolStripButton.Click += (s, e) => SaveDocument();
			saveToolStripMenuItem.Click += (s, e) => SaveDocument();
			saveAsToolStripMenuItem.Click += (s, e) => SaveAsDocument();

			groupRowsToolStripMenuItem.Click += groupRowsToolStripMenuItem_Click;
			groupRowsToolStripMenuItem1.Click += groupRowsToolStripMenuItem_Click;
			ungroupRowsToolStripMenuItem.Click += ungroupRowsToolStripMenuItem_Click;
			ungroupRowsToolStripMenuItem1.Click += ungroupRowsToolStripMenuItem_Click;
			ungroupAllRowsToolStripMenuItem.Click += ungroupAllRowsToolStripMenuItem_Click;
			ungroupAllRowsToolStripMenuItem1.Click += ungroupAllRowsToolStripMenuItem_Click;

			groupColumnsToolStripMenuItem.Click += groupColumnsToolStripMenuItem_Click;
			groupColumnsToolStripMenuItem1.Click += groupColumnsToolStripMenuItem_Click;
			ungroupColumnsToolStripMenuItem.Click += ungroupColumnsToolStripMenuItem_Click;
			ungroupColumnsToolStripMenuItem1.Click += ungroupColumnsToolStripMenuItem_Click;
			ungroupAllColumnsToolStripMenuItem.Click += ungroupAllColumnsToolStripMenuItem_Click;
			ungroupAllColumnsToolStripMenuItem1.Click += ungroupAllColumnsToolStripMenuItem_Click;

			hideRowsToolStripMenuItem.Click += (s, e) => this.grid.DoAction(new HideRowsAction(
				this.CurrentWorksheet.SelectionRange.Row, this.CurrentWorksheet.SelectionRange.Rows));
			unhideRowsToolStripMenuItem.Click += (s, e) => this.grid.DoAction(new UnhideRowsAction(
				this.CurrentWorksheet.SelectionRange.Row, this.CurrentWorksheet.SelectionRange.Rows));

			hideColumnsToolStripMenuItem.Click += (s, e) => this.grid.DoAction(new HideColumnsAction(
				this.CurrentWorksheet.SelectionRange.Col, this.CurrentWorksheet.SelectionRange.Cols));
			unhideColumnsToolStripMenuItem.Click += (s, e) => this.grid.DoAction(new UnhideColumnsAction(
				this.CurrentWorksheet.SelectionRange.Col, this.CurrentWorksheet.SelectionRange.Cols));

			// freeze to cell / edges
			freezeToCellToolStripMenuItem.Click += (s, e) => FreezeToEdge(FreezePosition.LeftTop);
			freezeToLeftToolStripMenuItem.Click += (s, e) => FreezeToEdge(FreezePosition.Left);
			freezeToTopToolStripMenuItem.Click += (s, e) => FreezeToEdge(FreezePosition.Top);
			freezeToRightToolStripMenuItem.Click += (s, e) => FreezeToEdge(FreezePosition.Right);
			freezeToBottomToolStripMenuItem.Click += (s, e) => FreezeToEdge(FreezePosition.Bottom);
			freezeToLeftTopToolStripMenuItem.Click += (s, e) => FreezeToEdge(FreezePosition.LeftTop);
			freezeToLeftBottomToolStripMenuItem.Click += (s, e) => FreezeToEdge(FreezePosition.LeftBottom);
			freezeToRightTopToolStripMenuItem.Click += (s, e) => FreezeToEdge(FreezePosition.RightTop);
			freezeToRightBottomToolStripMenuItem.Click += (s, e) => FreezeToEdge(FreezePosition.RightBottom);

			grid.GotFocus += (s, e) =>
				{
					cutToolStripButton.Enabled =
					cutToolStripMenuItem.Enabled =
					pasteToolStripButton.Enabled =
					pasteToolStripMenuItem.Enabled =
					copyToolStripButton.Enabled =
					copyToolStripMenuItem.Enabled =
						true;
				};

			grid.LostFocus += (s, e) =>
			{
				cutToolStripButton.Enabled =
				cutToolStripMenuItem.Enabled =
				pasteToolStripButton.Enabled =
				pasteToolStripMenuItem.Enabled =
				copyToolStripButton.Enabled =
				copyToolStripMenuItem.Enabled =
					false;
			};

			defineNamedRangeToolStripMenuItem.Click += (s, e) =>
			{
				var sheet = this.CurrentWorksheet;

				var name = sheet.GetNameByRange(sheet.SelectionRange);
				NamedRange namedRange = null;

				if (!string.IsNullOrEmpty(name))
				{
					namedRange = sheet.GetNamedRange(name);
				}

				using (DefineNamedRangeDialog dnrf = new DefineNamedRangeDialog())
				{
					dnrf.Range = sheet.SelectionRange;
					if (namedRange != null)
					{
						dnrf.RangeName = name;
						dnrf.Comment = namedRange.Comment;
					}

					if (dnrf.ShowDialog() == System.Windows.Forms.DialogResult.OK)
					{
						var newName = dnrf.RangeName;

						var existedRange = sheet.GetNamedRange(newName);
						if (existedRange != null)
						{
							if (MessageBox.Show(this, "Another range with this name has already existed, are you sure to overwrite it?",
								Application.ProductName, MessageBoxButtons.OKCancel, MessageBoxIcon.Question)
								== System.Windows.Forms.DialogResult.Cancel)
							{
								return;
							}

							sheet.UndefineNamedRange(newName);
						}

						var range = NamedRangeManageForm.DefineNamedRange(this, sheet, newName, dnrf.Comment, dnrf.Range);

						if (this.formulaBar != null && this.formulaBar.Visible)
						{
							this.formulaBar.RefreshCurrentAddress();
						}
					}
				}
			};

			this.nameManagerToolStripMenuItem.Click += (s, e) =>
			{
				if (this.nameManagerForm == null || this.nameManagerForm.IsDisposed)
				{
					this.nameManagerForm = new NamedRangeManageForm(this.grid);
				}

				this.nameManagerForm.Show(this);
			};

#if FORMULA_SUPPORT
			tracePrecedentsToolStripMenuItem.Click += (s, e) => this.CurrentWorksheet.TraceCellPrecedents(this.CurrentWorksheet.FocusPos);
			traceDependentsToolStripMenuItem.Click += (s, e) => this.CurrentWorksheet.TraceCellDependents(this.CurrentWorksheet.FocusPos);

			removeAllArrowsToolStripMenuItem.Click += (s, e) => this.CurrentWorksheet.RemoveRangeAllTraceArrows(this.CurrentWorksheet.SelectionRange);
			removePrecedentArrowsToolStripMenuItem.Click += (s, e) =>
				this.CurrentWorksheet.IterateCells(this.CurrentWorksheet.SelectionRange, (r, c, cell) =>
					this.CurrentWorksheet.RemoveCellTracePrecedents(cell));
			removeDependentArrowsToolStripMenuItem.Click += (s, e) =>
				this.CurrentWorksheet.IterateCells(this.CurrentWorksheet.SelectionRange, (r, c, cell) =>
					this.CurrentWorksheet.RemoveCellTraceDependents(cell));
#endif // FORMULA_SUPPORT

			columnPropertiesToolStripMenuItem.Click += (s, e) =>
			{
				var worksheet = this.CurrentWorksheet;

				int index = worksheet.SelectionRange.Col;
				int count = worksheet.SelectionRange.Cols;

				using (var hf = new HeaderPropertyDialog(RowOrColumn.Column))
				{
					var sampleHeader = worksheet.ColumnHeaders[index];

					hf.HeaderText = sampleHeader.Text;
					hf.HeaderTextColor = sampleHeader.TextColor ?? Color.Empty;
					hf.DefaultCellBody = sampleHeader.DefaultCellBody;

					if (hf.ShowDialog() == System.Windows.Forms.DialogResult.OK)
					{
						var newText = string.IsNullOrEmpty(hf.HeaderText) ? null : hf.HeaderText;

						for (int i = index; i < index + count; i++)
						{
							var header = worksheet.ColumnHeaders[i];

							if (string.IsNullOrEmpty(header.Text) || newText == null)
							{
								header.Text = newText;
							}

							header.TextColor = hf.HeaderTextColor;
							header.DefaultCellBody = hf.DefaultCellBody;
						}
					}
				}
			};

			rowPropertiesToolStripMenuItem.Click += (s, e) =>
			{
				var sheet = this.grid.CurrentWorksheet;

				int index = sheet.SelectionRange.Row;
				int count = sheet.SelectionRange.Rows;

				using (var hf = new HeaderPropertyDialog(RowOrColumn.Row))
				{
					var sampleHeader = sheet.RowHeaders[index];

					hf.HeaderText = sampleHeader.Text;
					hf.HeaderTextColor = sampleHeader.TextColor ?? Color.Empty;
					hf.RowHeaderWidth = sheet.RowHeaderWidth;

					if (hf.ShowDialog() == System.Windows.Forms.DialogResult.OK)
					{
						var newText = string.IsNullOrEmpty(hf.HeaderText) ? null : hf.HeaderText;

						for (int i = index; i < index + count; i++)
						{
							var header = sheet.RowHeaders[i];

							if (string.IsNullOrEmpty(header.Text) || newText == null)
							{
								header.Text = newText;
							}

							header.TextColor = hf.HeaderTextColor;
						}

						if (hf.RowHeaderWidth != sheet.RowHeaderWidth)
						{
							sheet.RowHeaderWidth = hf.RowHeaderWidth;
						}
					}
				}
			};

			printSettingsToolStripMenuItem.Click += (s, e) =>
			{
				using (PrintSettingsDialog psf = new PrintSettingsDialog())
				{
					var sheet = this.grid.CurrentWorksheet;

					if (sheet.PageSettings == null)
					{
						sheet.PageSettings = new PageSettings();
					}

					if (sheet.PrintSettings == null)
					{
						sheet.PrintSettings = new ReoGridPrintSettings();
					}

					psf.PageSettings = (PageSettings)sheet.PageSettings.Clone();
					psf.PrintSettings = (ReoGridPrintSettings)sheet.PrintSettings.Clone();

					if (psf.ShowDialog() == System.Windows.Forms.DialogResult.OK)
					{
						sheet.PageSettings = psf.PageSettings;
						sheet.PrintSettings = psf.PrintSettings;
						sheet.AutoSplitPage();
						sheet.EnableSettings(WorksheetSettings.View_ShowPageBreaks);
					}
				}
			};

			printToolStripMenuItem.Click += (s, e) =>
			{
				ReoGridPrintDocument doc = null;

				try
				{
					doc = grid.CurrentWorksheet.CreatePrintDocument();
				}
				catch (Exception ex)
				{
					MessageBox.Show(this, ex.Message, this.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
					return;
				}

				using (var pd = new System.Windows.Forms.PrintDialog())
				{
					pd.Document = grid.CurrentWorksheet.CreatePrintDocument();
					pd.UseEXDialog = true;

					if (pd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
					{
						doc.PrinterSettings = pd.PrinterSettings;
						doc.Print();
					}
				}

				if (doc != null) doc.Dispose();
			};

			foreach (var cellType in CellTypesManager.AvailableCellTypes)
			{
				var name = cellType.Name;
				if (name.EndsWith("Cell")) name = name.Substring(0, name.Length - 4);

				var menuItem = new ToolStripMenuItem(name)
				{
					Tag = cellType,
				};

				menuItem.Click += cellTypeMenuItem_Click;
				changeCellTypeToolStripMenuItem.DropDownItems.Add(menuItem);

				menuItem = new ToolStripMenuItem(name)
				{
					Tag = cellType,
				};
				menuItem.Click += cellTypeMenuItem_Click;
				changeCellsTypeToolStripMenuItem.DropDownItems.Add(menuItem);
			}

			rowContextMenuStrip.Opening += (s, e) =>
			{
				insertRowPageBreakToolStripMenuItem.Enabled = !this.grid.CurrentWorksheet.PrintableRange.IsEmpty;
				removeRowPageBreakToolStripMenuItem.Enabled = this.grid.CurrentWorksheet.RowPageBreakIndexes.Contains(this.grid.CurrentWorksheet.FocusPos.Row);
			};

			columnContextMenuStrip.Opening += (s, e) =>
			{
				insertColPageBreakToolStripMenuItem.Enabled = !this.grid.CurrentWorksheet.PrintableRange.IsEmpty;
				removeColPageBreakToolStripMenuItem.Enabled = this.grid.CurrentWorksheet.ColumnPageBreakIndexes.Contains(this.grid.CurrentWorksheet.FocusPos.Col);
			};

#if EX_SCRIPT
			scriptEditorToolStripMenuItem.Click += (s, e) =>
			{
				if (scriptEditor == null || scriptEditor.IsDisposed)
				{
					scriptEditor = new ReoScriptEditor();
					scriptEditor.Srm = this.grid.Srm;

					// synchronize script from the editor to control once the script is compiled 
					scriptEditor.ScriptCompiled += (ss, ee) =>
					{
						this.grid.Script = scriptEditor.Script;
					};
				}

				scriptEditor.Show();
				if (this.grid.Script == null)
				{
					this.grid.Script = Resources._default;
				}

				scriptEditor.Script = this.grid.Script;

				scriptEditor.Disposed += (ss, ee) => this.grid.Script = scriptEditor.Script;
			};

			runFunctionToolStripMenuItem.Click += (s, e) =>
			{
				using (var runFuncForm = new RunFunctionForm())
				{
					Cursor = Cursors.WaitCursor;

					if (this.grid.Srm != null && this.grid.Script != null)
					{
						var compiledScript = this.grid.Srm.Compile(
							scriptEditor.Visible ? scriptEditor.Script : this.grid.Script);
						runFuncForm.Srm = this.grid.Srm;
						runFuncForm.Script = compiledScript;
					}

					Cursor = Cursors.Default;

					runFuncForm.ShowDialog(this);
				}
			};

#else // EX_SCRIPT

			//scriptToolStripMenuItem.Visible = false;
			scriptEditorToolStripMenuItem.Click += (s, e) =>
			{
			  MessageBox.Show("Script execution is not supported by this edition.", Application.ProductName);
			};
#endif

			homepageToolStripMenuItem.Click += (s, e) =>
			{
				try
				{
					Process.Start("http://reogrid.net/");
				}
				catch { }
			};

			documentationToolStripMenuItem.Click += (s, e) =>
			{
				try
				{
					Process.Start("http://reogrid.net/document");
				}
				catch { }
			};

			insertColPageBreakToolStripMenuItem.Click += insertColPageBreakToolStripMenuItem_Click;
			insertRowPageBreakToolStripMenuItem.Click += insertRowPageBreakToolStripMenuItem_Click;
			removeColPageBreakToolStripMenuItem.Click += removeColPageBreakToolStripMenuItem_Click;
			removeRowPageBreakToolStripMenuItem.Click += removeRowPageBreakToolStripMenuItem_Click;

			filterToolStripMenuItem.Click += filterToolStripMenuItem_Click;
			clearFilterToolStripMenuItem.Click += clearFilterToolStripMenuItem_Click;
			columnFilterToolStripMenuItem.Click += filterToolStripMenuItem_Click;
			clearColumnFilterToolStripMenuItem.Click += clearFilterToolStripMenuItem_Click;

			this.grid.ExceptionHappened += (s, e) =>
			{
				if (e.Exception is RangeIntersectionException)
				{
					MessageBox.Show(this, "Cannot process a range that contains another a part of merged cell.",
						"ReoGrid Editor", MessageBoxButtons.OK, MessageBoxIcon.Stop);
				}
			};

			this.grid.CurrentWorksheetChanged += (s, e) =>
				{
					UpdateMenuAndToolStrips();
					worksheet_GridScaled(s, e);

					UpdateWorksheetSettings(this.grid.CurrentWorksheet);
					UpdateSelectionModeAndStyle();
					UpdateSelectionForwardDirection();
				};

			this.grid.SettingsChanged += (s, e) =>
				{
					sheetSwitcherToolStripMenuItem.Checked = this.grid.HasSettings(WorkbookSettings.View_ShowSheetTabControl);
					showHorizontaScrolllToolStripMenuItem.Checked = this.grid.HasSettings(WorkbookSettings.View_ShowHorScroll);
					showVerticalScrollbarToolStripMenuItem.Checked = this.grid.HasSettings(WorkbookSettings.View_ShowVerScroll);
				};

			this.clearDataToolStripMenuItem.Click += (s, e) =>
				this.CurrentWorksheet.ClearRangeContent(this.CurrentSelectionRange, CellElementFlag.Data);
			this.clearDataFormatToolStripMenuItem.Click += (s, e) =>
				this.CurrentWorksheet.ClearRangeContent(this.CurrentSelectionRange, CellElementFlag.DataFormat);
			this.clearDataFormatToolStripMenuItem.Click += (s, e) =>
				this.CurrentWorksheet.ClearRangeContent(this.CurrentSelectionRange, CellElementFlag.Formula);
			this.clearCellBodyToolStripMenuItem.Click += (s, e) =>
				this.CurrentWorksheet.ClearRangeContent(this.CurrentSelectionRange, CellElementFlag.Body);
			this.clearStylesToolStripMenuItem.Click += (s, e) =>
				this.CurrentWorksheet.ClearRangeContent(this.CurrentSelectionRange, CellElementFlag.Style);
			this.clearBordersToolStripButton.Click += (s, e) =>
				this.CurrentWorksheet.ClearRangeContent(this.CurrentSelectionRange, CellElementFlag.Border);

			this.exportCurrentWorksheetToolStripMenuItem.Click += (s, e) => ExportAsCsv(ReoGridRange.EntireRange);

			this.exportSelectedRangeToolStripMenuItem.Click += (s, e) => ExportAsCsv(CurrentSelectionRange);
#if DEBUG

			this.showDebugFormToolStripButton.Click += new System.EventHandler(this.showDebugFormToolStripButton_Click);

			#region Debug Validation Events
			this.grid.WorksheetInserted += (ss, ee) =>
			{
				var worksheet = ee.Worksheet;

				worksheet.RowInserted += (s, e) => _Debug_Auto_Validate_All((Worksheet)s);
				worksheet.ColumnsInserted += (s, e) => _Debug_Auto_Validate_All((Worksheet)s);
				worksheet.RowDeleted += (s, e) => _Debug_Auto_Validate_All((Worksheet)s);
				worksheet.ColumnsDeleted += (s, e) => _Debug_Auto_Validate_All((Worksheet)s);
				worksheet.RangeMerged += (s, e) => _Debug_Auto_Validate_All((Worksheet)s);
				worksheet.RangeUnmerged += (s, e) => _Debug_Auto_Validate_All((Worksheet)s, e.Range);
				worksheet.AfterPaste += (s, e) => _Debug_Auto_Validate_All((Worksheet)s);
			};

			this.grid.Undid += (s, e) => _Debug_Auto_Validate_All(((BaseWorksheetAction)e.Action).Worksheet);
			this.grid.Redid += (s, e) => _Debug_Auto_Validate_All(((BaseWorksheetAction)e.Action).Worksheet);

			showDebugInfoToolStripMenuItem.Click += (s, e) =>
			{
				showDebugFormToolStripButton.PerformClick();
				showDebugInfoToolStripMenuItem.Checked = showDebugFormToolStripButton.Checked;
			};

			validateBorderSpanToolStripMenuItem.Click += (s, e) => _Debug_Validate_BorderSpan(this.CurrentWorksheet, true);
			validateMergedRangeToolStripMenuItem.Click += (s, e) => _Debug_Validate_Merged_Cell(this.CurrentWorksheet, true);
			validateAllToolStripMenuItem.Click += (s, e) => _Debug_Validate_All(this.CurrentWorksheet, true);
			#endregion
#endif // DEBUG

			ResumeLayout();

            tsu = toolStrip1;

            tsl = fontToolStrip;

		}

		private void ExportAsCsv(ReoGridRange range)
		{
			using (SaveFileDialog dlg = new SaveFileDialog())
			{
				dlg.Filter = "CSV File(*.csv)|*.csv|Text file(*.txt)|*.txt|All files(*.*)|*.*";
				dlg.FileName = Path.GetFileNameWithoutExtension(this.CurrentFilePath);

				if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
				{
					using (FileStream fs = new FileStream(dlg.FileName, FileMode.Create, FileAccess.Write, FileShare.Read))
					{
						CurrentWorksheet.ExportAsCSV(fs, range);
					}

#if DEBUG
					Process.Start(dlg.FileName);
#endif
				}
			};


        

		}

        public ToolStrip tsu { get; set; }

        public ToolStrip tsl { get; set; }

        public void toggletools()
        {

            toggle(tsu);
            toggle(tsl);
            toggle(formulaBar);

        }


        static public void toggle(Control c)
        {


            if (c.Visible == true)
                c.Visible = false;
            else
                c.Visible = true;



        }

		void worksheet_SelectionModeChanged(object sender, EventArgs e)
		{
			UpdateSelectionModeAndStyle();
		}

		void worksheet_SelectionForwardDirectionChanged(object sender, EventArgs e)
		{
			UpdateSelectionForwardDirection();
		}

		void worksheet_Resetted(object sender, EventArgs e)
		{
			statusToolStripStatusLabel.Text = string.Empty;
		}

		void worksheet_SettingsChanged(object sender, SettingsChangedEventArgs e)
		{
			var worksheet = sender as Worksheet;
			if (worksheet != null) UpdateWorksheetSettings(worksheet);
		}

		void UpdateWorksheetSettings(Worksheet sheet)
		{
			bool visible = false;

			visible = sheet.HasSettings(WorksheetSettings.View_ShowGridLine);
			if (showGridLinesToolStripMenuItem.Checked != visible) showGridLinesToolStripMenuItem.Checked = visible;

			visible = sheet.HasSettings(WorksheetSettings.View_ShowPageBreaks);
			if (showPageBreakToolStripMenuItem.Checked != visible) showPageBreakToolStripMenuItem.Checked = visible;

			visible = sheet.HasSettings(WorksheetSettings.View_ShowRowHeader);
			if (showRowHeaderToolStripMenuItem.Checked != visible) showRowHeaderToolStripMenuItem.Checked = visible;

			visible = sheet.HasSettings(WorksheetSettings.View_ShowColumnHeader);
			if (showColumnHeaderToolStripMenuItem.Checked != visible) showColumnHeaderToolStripMenuItem.Checked = visible;

			visible = sheet.HasSettings(WorksheetSettings.View_AllowShowRowOutlines);
			if (showRowOutlineToolStripMenuItem.Checked != visible) showRowOutlineToolStripMenuItem.Checked = visible;

			visible = sheet.HasSettings(WorksheetSettings.View_AllowShowColumnOutlines);
			if (showColumnOutlineToolStripMenuItem.Checked != visible) showColumnOutlineToolStripMenuItem.Checked = visible;

			sheetReadonlyToolStripMenuItem.Checked = sheet.HasSettings(WorksheetSettings.Edit_Readonly);
		}

		void cellTypeMenuItem_Click(object sender, EventArgs e)
		{
			var worksheet = this.CurrentWorksheet;

			var menuItem = sender as ToolStripMenuItem;

			if (menuItem != null && menuItem.Tag is Type)
			{
				var range = worksheet.SelectionRange;

				for (int r = range.Row; r <= range.EndRow; r++)
				{
					for (int c = range.Col; c <= range.EndCol; c++)
					{
						var cell = worksheet.Cells[r, c];
						cell.Body = System.Activator.CreateInstance((Type)menuItem.Tag) as CellBody;
					}
				}
			}
		}

		void textWrapToolStripButton_Click(object sender, EventArgs e)
		{
			var worksheet = this.CurrentWorksheet;

			if (textWrapToolStripButton.Checked)
			{
				this.grid.DoAction(new SetRangeStyleAction(worksheet.SelectionRange, new ReoGridStyleObject
				{
					Flag = PlainStyleFlag.TextWrap,
					TextWrapMode = TextWrapMode.WordBreak,
				}));
			}
			else
			{
				this.grid.DoAction(new RemoveRangeStyleAction(worksheet.SelectionRange, PlainStyleFlag.TextWrap)); // TODO
			}
		}

		void worksheet_GridScaled(object sender, EventArgs e)
		{
			zoomToolStripDropDownButton.Text = this.grid.CurrentWorksheet.ScaleFactor * 100 + "%";
		}

		#endregion // Constructor

		#region Utility

#if DEBUG
		#region Debug Validations
		/// <summary>
		/// Use for Debug mode. Check for border span is valid.
		/// </summary>
		/// <param name="showSuccessMsg"></param>
		/// <returns></returns>
		bool _Debug_Validate_BorderSpan(Worksheet sheet, bool showSuccessMsg)
		{
			bool rs = true;//sheet._Debug_Validate_BorderSpan();

			if (rs)
			{
				if (showSuccessMsg) ShowStatus("Border span validation ok.");
			}
			else
			{
				ShowError("Border span test failed.");

				if (!showDebugInfoToolStripMenuItem.Checked)
				{
					showDebugInfoToolStripMenuItem.PerformClick();
				}
			}

			return rs;
		}
		bool _Debug_Validate_Merged_Cell(Worksheet sheet, bool showSuccessMsg)
		{
            bool rs = true;// sheet._Debug_Validate_MergedCells();

			if (rs)
			{
				if (showSuccessMsg) ShowStatus("Merged range validation ok.");
			}
			else
			{
				ShowError("Merged range validation failed.");

				if (!showDebugInfoToolStripMenuItem.Checked)
				{
					showDebugInfoToolStripMenuItem.PerformClick();
				}
			}

			return rs;
		}
		bool _Debug_Validate_Unmerged_Range(Worksheet sheet, bool showSuccessMsg, ReoGridRange range)
		{
            bool rs = true;// sheet._Debug_Validate_Unmerged_Range(range);

			if (rs)
			{
				if (showSuccessMsg) ShowStatus("Unmerged range validation ok.");
			}
			else
			{
				ShowError("Unmerged range validation failed.");

				if (!showDebugInfoToolStripMenuItem.Checked)
				{
					showDebugInfoToolStripMenuItem.PerformClick();
				}
			}

			return rs;
		}
		bool _Debug_Validate_All(Worksheet sheet, bool showSuccessMsg)
		{
			return _Debug_Validate_All(sheet, showSuccessMsg, ReoGridRange.EntireRange);
		}
		bool _Debug_Validate_All(Worksheet sheet, ReoGridRange range)
		{
			return _Debug_Validate_All(sheet, false, range);
		}
		bool _Debug_Validate_All(Worksheet sheet, bool showSuccessMsg, ReoGridRange range)
		{
			bool rs = _Debug_Validate_BorderSpan(sheet, showSuccessMsg);
			if (rs) rs = _Debug_Validate_Merged_Cell(sheet, showSuccessMsg);
			if (rs) rs = _Debug_Validate_Unmerged_Range(sheet, showSuccessMsg, range);

			return rs;
		}
		bool _Debug_Auto_Validate_All(Worksheet sheet) { return _Debug_Validate_All(sheet, false); }
		bool _Debug_Auto_Validate_All(Worksheet sheet, ReoGridRange range) { return _Debug_Validate_All(sheet, range); }
		#endregion // Debug Validations
#endif // DEBUG

		public ReoGridControl GridControl { get { return this.grid; } }

		public Worksheet CurrentWorksheet { get { return this.grid.CurrentWorksheet; } }

		public ReoGridRange CurrentSelectionRange
		{
			get { return this.grid.CurrentWorksheet.SelectionRange; }
			set { this.grid.CurrentWorksheet.SelectionRange = value; }
		}

#if EX_SCRIPT
		private ReoScriptEditor scriptEditor;
		public ReoScriptEditor ScriptEditor { get { return scriptEditor; } }
#endif // EX_SCRIPT

		internal void ShowStatus(string msg)
		{
			ShowStatus(msg, false);
		}
		internal void ShowStatus(string msg, bool error)
		{
			statusToolStripStatusLabel.Text = msg;
			statusToolStripStatusLabel.ForeColor = error ? Color.Red : SystemColors.WindowText;
		}
		public void ShowError(string msg)
		{
			ShowStatus(msg, true);
		}

		private void UpdateMenuAndToolStripsWhenAction(object sender, EventArgs e)
		{
			UpdateMenuAndToolStrips();
		}

		private void Undo(object sender, EventArgs e)
		{
			this.grid.Undo();
		}

		private void Redo(object sender, EventArgs e)
		{
			this.grid.Redo();
		}

		void zoomToolStripDropDownButton_TextChanged(object sender, EventArgs e)
		{
			if (isUIUpdating) return;

			if (zoomToolStripDropDownButton.Text.Length > 0)
			{
				int value = 100;
				if (int.TryParse(zoomToolStripDropDownButton.Text.Substring(0, zoomToolStripDropDownButton.Text.Length - 1), out value))
				{
					this.CurrentWorksheet.SetScale((float)value / 100f);
				}
			}
		}

		void grid_SelectionRangeChanged(object sender, RangeEventArgs e)
		{
			// get event source worksheet
			var worksheet = sender as Worksheet;

			// if source worksheet is current worksheet, update menus and tool strips
			if (worksheet == this.CurrentWorksheet)
			{
				if (worksheet.SelectionRange == ReoGridRange.Empty)
				{
					rangeInfoToolStripStatusLabel.Text = "Selection None";
				}
				else
				{
					rangeInfoToolStripStatusLabel.Text =
						string.Format("{0} {1} x {2}", worksheet.SelectionRange.ToString(),
						worksheet.SelectionRange.Rows, worksheet.SelectionRange.Cols);
				}

				UpdateMenuAndToolStrips();
			}
		}

		#endregion // Utility

		#region Update Menus & Toolbars
		private bool isUIUpdating = false;
		private void UpdateMenuAndToolStrips()
		{
			if (isUIUpdating)
				return;

			isUIUpdating = true;

			var worksheet = this.CurrentWorksheet;

			ReoGridStyleObject style = worksheet.GetCellStyle(worksheet.SelectionRange.StartPos);
			if (style != null)
			{
				// cross-thread exception
				Action set = () =>
				{
					fontToolStripComboBox.Text = style.FontName;
					fontSizeToolStripComboBox.Text = style.FontSize.ToString();
					boldToolStripButton.Checked = style.Bold;
					italicToolStripButton.Checked = style.Italic;
					strikethroughToolStripButton.Checked = style.Strikethrough;
					underlineToolStripButton.Checked = style.Underline;
					textColorPickToolStripItem.SolidColor = style.TextColor;
					backColorPickerToolStripButton.SolidColor = style.BackColor;
					textAlignLeftToolStripButton.Checked = style.HAlign == ReoGridHorAlign.Left;
					textAlignCenterToolStripButton.Checked = style.HAlign == ReoGridHorAlign.Center;
					textAlignRightToolStripButton.Checked = style.HAlign == ReoGridHorAlign.Right;
					distributedIndentToolStripButton.Checked = style.HAlign == ReoGridHorAlign.DistributedIndent;
					textAlignTopToolStripButton.Checked = style.VAlign == ReoGridVerAlign.Top;
					textAlignMiddleToolStripButton.Checked = style.VAlign == ReoGridVerAlign.Middle;
					textAlignBottomToolStripButton.Checked = style.VAlign == ReoGridVerAlign.Bottom;
					textWrapToolStripButton.Checked = style.TextWrapMode != TextWrapMode.NoWrap;

					ReoGridRangeBorderInfo borderInfo = worksheet.GetRangeBorders(worksheet.SelectionRange);
					if (borderInfo.Left != null && !borderInfo.Left.Color.IsEmpty)
					{
						borderColorPickToolStripItem.SolidColor = borderInfo.Left.Color;
					}
					else if (borderInfo.Right != null && !borderInfo.Right.Color.IsEmpty)
					{
						borderColorPickToolStripItem.SolidColor = borderInfo.Right.Color;
					}
					else if (borderInfo.Top != null && !borderInfo.Top.Color.IsEmpty)
					{
						borderColorPickToolStripItem.SolidColor = borderInfo.Top.Color;
					}
					else if (borderInfo.Bottom != null && !borderInfo.Bottom.Color.IsEmpty)
					{
						borderColorPickToolStripItem.SolidColor = borderInfo.Bottom.Color;
					}
					else if (borderInfo.InsideHorizontal != null && !borderInfo.InsideHorizontal.Color.IsEmpty)
					{
						borderColorPickToolStripItem.SolidColor = borderInfo.InsideHorizontal.Color;
					}
					else if (borderInfo.InsideVertical != null && !borderInfo.InsideVertical.Color.IsEmpty)
					{
						borderColorPickToolStripItem.SolidColor = borderInfo.InsideVertical.Color;
					}
					else
					{
						borderColorPickToolStripItem.SolidColor = Color.Black;
					}

					undoToolStripButton.Enabled =
						undoToolStripMenuItem.Enabled =
						this.grid.CanUndo();

					redoToolStripButton.Enabled =
						redoToolStripMenuItem.Enabled =
						this.grid.CanRedo();

					repeatLastActionToolStripMenuItem.Enabled =
						this.grid.CanUndo() || this.grid.CanRedo();

					cutToolStripButton.Enabled =
						cutToolStripMenuItem.Enabled =
						worksheet.CanCut();

					copyToolStripButton.Enabled =
						copyToolStripMenuItem.Enabled =
						worksheet.CanCopy();

					pasteToolStripButton.Enabled =
						pasteToolStripMenuItem.Enabled =
						worksheet.CanPaste();

					// from 0.8.6 - allow change freeze location anytime
					//freezeToCellToolStripMenuItem.Enabled = workbook.CanFreeze();
					unfreezeToolStripMenuItem.Enabled = worksheet.IsForzen();

					isUIUpdating = false;
				};

				if (this.InvokeRequired)
					this.Invoke(set);
				else
					set();
			}

#if !DEBUG
			debugToolStripMenuItem.Enabled = false;
#endif

		}

		private bool settingSelectionMode = false;

		private void UpdateSelectionModeAndStyle()
		{
			if (settingSelectionMode) return;

			settingSelectionMode = true;

			selModeNoneToolStripMenuItem.Checked = false;
			selModeCellToolStripMenuItem.Checked = false;
			selModeRangeToolStripMenuItem.Checked = false;
			selModeRowToolStripMenuItem.Checked = false;
			selModeColumnToolStripMenuItem.Checked = false;

			switch (this.CurrentWorksheet.SelectionMode)
			{
				case ReoGridSelectionMode.None:
					selModeNoneToolStripMenuItem.Checked = true;
					break;
				case ReoGridSelectionMode.Cell:
					selModeCellToolStripMenuItem.Checked = true;
					break;
				default:
				case ReoGridSelectionMode.Range:
					selModeRangeToolStripMenuItem.Checked = true;
					break;
				case ReoGridSelectionMode.Row:
					selModeRowToolStripMenuItem.Checked = true;
					break;
				case ReoGridSelectionMode.Column:
					selModeColumnToolStripMenuItem.Checked = true;
					break;
			}

			selStyleNoneToolStripMenuItem.Checked = false;
			selStyleDefaultToolStripMenuItem.Checked = false;
			selStyleFocusRectToolStripMenuItem.Checked = false;

			switch (this.CurrentWorksheet.SelectionStyle)
			{
				case ReoGridSelectionStyle.None:
					selStyleNoneToolStripMenuItem.Checked = true;
					break;
				default:
				case ReoGridSelectionStyle.Default:
					selStyleDefaultToolStripMenuItem.Checked = true;
					break;
				case ReoGridSelectionStyle.FocusRect:
					selStyleFocusRectToolStripMenuItem.Checked = true;
					break;
			}

			settingSelectionMode = false;
		}
		private void UpdateSelectionForwardDirection()
		{
			switch (this.CurrentWorksheet.SelectionForwardDirection)
			{
				default:
				case SelectionForwardDirection.Right:
					selDirRightToolStripMenuItem.Checked = true;
					selDirDownToolStripMenuItem.Checked = false;
					break;
				case SelectionForwardDirection.Down:
					selDirRightToolStripMenuItem.Checked = false;
					selDirDownToolStripMenuItem.Checked = true;
					break;
			}
		}
		#endregion

		#region Document
		public string CurrentFilePath { get; set; }
		private string currentTempFilePath;

		/// <summary>
		/// Load spreadsheet form specified file
		/// </summary>
		/// <param name="path">path to load file</param>
		public void LoadFile(string path)
		{
			LoadFile(path, Encoding.Default);
		}

		/// <summary>
		/// Load spreadsheet from specified file
		/// </summary>
		/// <param name="path">path to load file</param>
		/// <param name="encoding">encoding to read input stream</param>
		public void LoadFile(string path, Encoding encoding)
		{
			this.CurrentFilePath = null;

			var worksheet = this.CurrentWorksheet;

			bool success = false;

			grid.CurrentWorksheet.Reset();

			try
			{
				grid.Load(path, IO.FileFormat._Auto, encoding);
				success = true;
			}
			catch (FileNotFoundException ex)
			{
				success = false;
				MessageBox.Show("Specified file cannot be found: " + ex.FileName, "ReoGridEditor", MessageBoxButtons.OK, MessageBoxIcon.Stop);
			}
			catch (Exception ex)
			{
				success = false;
				MessageBox.Show("Load file failed: " + ex.Message, "ReoGridEditor", MessageBoxButtons.OK, MessageBoxIcon.Stop);
			}

			if (success)
			{
				this.Text = System.IO.Path.GetFileName(path) + " - ReoGrid Editor " + this.ProductVersion;
				showGridLinesToolStripMenuItem.Checked = worksheet.HasSettings(WorksheetSettings.View_ShowGridLine);
				ShowStatus(string.Empty);
				this.CurrentFilePath = path;
				this.currentTempFilePath = null;

#if EX_SCRIPT
				// check whether grid contains any scripts
				if (!string.IsNullOrEmpty(this.grid.Script))
				{
					if (MessageBox.Show("The document contains macro and executable script. Do you want to run the script now?",
						"Executable Script", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
					{
						if (scriptEditor == null)
						{
							scriptEditor = new ReoScriptEditor()
							{
								Script = this.grid.Script,
								Srm = this.grid.Srm,
							};
						}

						// run init script
						this.grid.RunScript();

						// show script editor window
						if (!scriptEditor.Visible)
						{
							scriptEditor.Show();
						}
					}
				}
#endif
			}
		}
		private void NewFile()
		{
			if (!CloseDocument())
			{
				return;
			}

			this.grid.Reset();

			this.Text = "Untitled - ReoGrid Editor " + this.ProductVersion;

			//showGridLinesToolStripMenuItem.Checked = workbook.HasSettings(ReoGridSettings.View_ShowGridLine);
			this.CurrentFilePath = null;
			this.currentTempFilePath = null;

#if DEBUG // for test case
			//showDebugFormToolStripButton.PerformClick();
			ForTest();
#endif
		}

		private void SaveFile(string path)
		{
#if EX_SCRIPT
			if (scriptEditor != null && scriptEditor.Visible)
			{
				this.grid.Script = scriptEditor.Script;
			}
#endif // EX_SCRIPT

			//, "ReoGridEditor " + this.ProductVersion.ToString())
			FileFormat fm = FileFormat._Auto;
			if (path.EndsWith(".xlsx", StringComparison.CurrentCultureIgnoreCase))
				fm = FileFormat.Excel2007;
			else if (path.EndsWith(".rgf", StringComparison.CurrentCultureIgnoreCase))
				fm = FileFormat.ReoGridFormat;
			else if (path.EndsWith(".csv", StringComparison.CurrentCultureIgnoreCase))
				fm = FileFormat.CSV;

			try
			{
				this.grid.Save(path, fm);

				this.SetCurrentDocumentFile(path);

#if DEBUG
				Process.Start(path);
#endif
			}
			catch (Exception ex)
			{
				MessageBox.Show(this, "Save error: " + ex.Message, "Save Workbook", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		private void SetCurrentDocumentFile(string filepath)
		{
			this.Text = System.IO.Path.GetFileName(filepath) + " - ReoGrid Editor " + this.ProductVersion;
			this.CurrentFilePath = filepath;
			this.currentTempFilePath = null;
		}

		private void newToolStripButton_Click(object sender, EventArgs e)
		{
			NewFile();
		}

		private void loadToolStripButton_Click(object sender, EventArgs e)
		{
			using (OpenFileDialog ofd = new OpenFileDialog())
			{
				ofd.Filter = "All Supported Files(*.xlsx;*.csv;*.rgf)|*.xlsx;*.csv;*.rgf|ReoGrid XML Format(*.rgf)|*.rgf|Excel 2007(*.xlsx)|*.xlsx|CSV File(*.csv)|*.csv|All Files(*.*)|*.*";

				if (ofd.ShowDialog(this) == DialogResult.OK)
				{
					LoadFile(ofd.FileName);
					this.SetCurrentDocumentFile(ofd.FileName);
				}
			}
		}

		/// <summary>
		/// Save current document
		/// </summary>
		public void SaveDocument()
		{
			if (string.IsNullOrEmpty(CurrentFilePath))
			{
				SaveAsDocument();
			}
			else
			{
				SaveFile(this.CurrentFilePath);
			}
		}

		/// <summary>
		/// Save current document by specifying new file path
		/// </summary>
		/// <returns>true if operation is successful, otherwise false</returns>
		public bool SaveAsDocument()
		{
			using (SaveFileDialog sfd = new SaveFileDialog())
			{
				sfd.Filter = "Excel 2007(*.xlsx)|*.xlsx|ReoGrid XML Format(*.rgf)|*.rgf|CSV File(*.csv)|*.csv|All Files(*.*)|*.*";

				if (!string.IsNullOrEmpty(this.CurrentFilePath))
				{
					sfd.FileName = Path.GetFileNameWithoutExtension(this.CurrentFilePath);

					var format = GetFormatByExtension(this.CurrentFilePath);
					switch (format)
					{
						case FileFormat.Excel2007:
							sfd.FilterIndex = 1;
							break;
						case FileFormat.ReoGridFormat:
							sfd.FilterIndex = 2;
							break;
						case FileFormat.CSV:
							sfd.FilterIndex = 3;
							break;
					}
				}

				if (sfd.ShowDialog(this) == DialogResult.OK)
				{
					SaveFile(sfd.FileName);
					return true;
				}
			}

			return false;
		}

		/// <summary>
		/// Event raised when document has been reset to initial
		/// </summary>
		public bool NewDocumentOnLoad { get; set; }

		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad(e);

#if DEBUG
			if (Toolkit.IsKeyDown(unvell.Common.Win32Lib.Win32.VKey.VK_CONTROL))
			{
				FileInfo file = new FileInfo("..\\..\\autosave.sgf");
				if (file.Exists) LoadFile(file.FullName);
			}
#endif

			// load file if specified 
			if (!string.IsNullOrEmpty(CurrentFilePath))
			{
				this.grid.Reset();
				LoadFile(CurrentFilePath);
			}
			else if (NewDocumentOnLoad)
			{
				NewFile();
			}

#if EX_SCRIPT
			if (!string.IsNullOrEmpty(this.grid.Script) && (scriptEditor == null || !scriptEditor.Visible || scriptEditor.IsDisposed))
			{
				scriptEditorToolStripMenuItem.PerformClick();
			}
#endif // EX_SCRIPT

			UpdateSelectionModeAndStyle();
			UpdateSelectionForwardDirection();

			grid.Focus();
		}

		protected override void OnClosing(CancelEventArgs e)
		{
			base.OnClosing(e);

#if DEBUG
			if (Toolkit.IsKeyDown(unvell.Common.Win32Lib.Win32.VKey.VK_CONTROL))
			{
				this.CurrentWorksheet.Save("..\\..\\autosave.sgf");
			}
#endif // DEBUG
		}

		private void newToolStripMenuItem_Click(object sender, EventArgs e)
		{
			newToolStripButton.PerformClick();
		}

		private void openToolStripMenuItem_Click(object sender, EventArgs e)
		{
			loadToolStripButton.PerformClick();
		}

		public bool CloseDocument()
		{
			if (this.grid.IsWorkbookEmpty)
			{
				return true;
			}

			var dr = MessageBox.Show("Do you want to save changes?", "ReoGrid Editor", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);

			if (dr == System.Windows.Forms.DialogResult.No)
				return true;
			else if (dr == System.Windows.Forms.DialogResult.Cancel)
				return false;

			FileFormat format = FileFormat._Auto;

			if (!string.IsNullOrEmpty(this.CurrentFilePath))
			{
				format = GetFormatByExtension(this.CurrentFilePath);
			}

			if (format == FileFormat._Auto || string.IsNullOrEmpty(this.CurrentFilePath))
			{
				return SaveAsDocument();
			}
			else
			{
				SaveDocument();
			}

			return true;
		}

		private FileFormat GetFormatByExtension(string path)
		{
			if (string.IsNullOrEmpty(path))
			{
				return FileFormat._Auto;
			}

			string ext = Path.GetExtension(this.CurrentFilePath);

			if (ext.Equals(".rgf", StringComparison.CurrentCultureIgnoreCase)
				|| ext.Equals(".xml", StringComparison.CurrentCultureIgnoreCase))
			{
				return FileFormat.ReoGridFormat;
			}
			else if (ext.Equals(".xlsx", StringComparison.CurrentCultureIgnoreCase))
			{
				return FileFormat.Excel2007;
			}
			else if (ext.Equals(".csv", StringComparison.CurrentCultureIgnoreCase))
			{
				return FileFormat.CSV;
			}
			else
			{
				return FileFormat._Auto;
			}
		}

		#endregion

		#region Alignment
		private void textLeftToolStripButton_Click(object sender, EventArgs e)
		{
			this.grid.DoAction(new SetRangeStyleAction(this.CurrentWorksheet.SelectionRange, new ReoGridStyleObject
			{
				Flag = PlainStyleFlag.HorizontalAlign,
				HAlign = ReoGridHorAlign.Left,
			}));
		}
		private void textCenterToolStripButton_Click(object sender, EventArgs e)
		{
			this.grid.DoAction(new SetRangeStyleAction(this.CurrentWorksheet.SelectionRange, new ReoGridStyleObject
			{
				Flag = PlainStyleFlag.HorizontalAlign,
				HAlign = ReoGridHorAlign.Center,
			}));
		}
		private void textRightToolStripButton_Click(object sender, EventArgs e)
		{
			this.grid.DoAction(new SetRangeStyleAction(this.CurrentWorksheet.SelectionRange, new ReoGridStyleObject
			{
				Flag = PlainStyleFlag.HorizontalAlign,
				HAlign = ReoGridHorAlign.Right,
			}));
		}
		private void distributedIndentToolStripButton_Click(object sender, EventArgs e)
		{
			this.grid.DoAction(new SetRangeStyleAction(this.CurrentWorksheet.SelectionRange, new ReoGridStyleObject
			{
				Flag = PlainStyleFlag.HorizontalAlign,
				HAlign = ReoGridHorAlign.DistributedIndent,
			}));
		}

		private void textAlignTopToolStripButton_Click(object sender, EventArgs e)
		{
			this.grid.DoAction(new SetRangeStyleAction(this.CurrentWorksheet.SelectionRange, new ReoGridStyleObject
			{
				Flag = PlainStyleFlag.VerticalAlign,
				VAlign = ReoGridVerAlign.Top,
			}));
		}
		private void textAlignMiddleToolStripButton_Click(object sender, EventArgs e)
		{
			this.grid.DoAction(new SetRangeStyleAction(this.CurrentWorksheet.SelectionRange, new ReoGridStyleObject
			{
				Flag = PlainStyleFlag.VerticalAlign,
				VAlign = ReoGridVerAlign.Middle,
			}));
		}
		private void textAlignBottomToolStripButton_Click(object sender, EventArgs e)
		{
			this.grid.DoAction(new SetRangeStyleAction(this.CurrentWorksheet.SelectionRange, new ReoGridStyleObject
			{
				Flag = PlainStyleFlag.VerticalAlign,
				VAlign = ReoGridVerAlign.Bottom,
			}));
		}
		#endregion

		#region Border Settings

		#region Outline Borders
		private void SetSelectionBorder(BorderPositions borderPos, BorderLineStyle style)
		{
			this.grid.DoAction(new SetRangeBorderAction(this.CurrentWorksheet.SelectionRange, borderPos,
				new BorderStyle { Color = borderColorPickToolStripItem.SolidColor, Style = style }));
		}

		private void boldOutlineToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.Outside, BorderLineStyle.BoldSolid);
		}
		private void dottedOutlineToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.Outside, BorderLineStyle.Dotted);
		}
		private void boundsSolidToolStripButton_ButtonClick(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.Outside, BorderLineStyle.Solid);
		}
		private void solidOutlineToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.Outside, BorderLineStyle.Solid);
		}
		private void dashedOutlineToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.Outside, BorderLineStyle.Dashed);
		}
		#endregion

		#region Inside Borders
		private void insideSolidToolStripSplitButton_ButtonClick(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.InsideAll, BorderLineStyle.Solid);
		}
		private void insideSolidToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.InsideAll, BorderLineStyle.Solid);
		}
		private void insideBoldToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.InsideAll, BorderLineStyle.BoldSolid);
		}
		private void insideDottedToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.InsideAll, BorderLineStyle.Dotted);
		}
		private void insideDashedToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.InsideAll, BorderLineStyle.Dashed);
		}
		#endregion

		#region Left & Right Borders
		private void leftRightSolidToolStripSplitButton_ButtonClick(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.LeftRight, BorderLineStyle.Solid);
		}
		private void leftRightSolidToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.LeftRight, BorderLineStyle.Solid);
		}
		private void leftRightBoldToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.LeftRight, BorderLineStyle.BoldSolid);
		}
		private void leftRightDotToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.LeftRight, BorderLineStyle.Dotted);
		}
		private void leftRightDashToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.LeftRight, BorderLineStyle.Dashed);
		}
		#endregion

		#region Top & Bottom Borders
		private void topBottomSolidToolStripSplitButton_ButtonClick(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.TopBottom, BorderLineStyle.Solid);
		}
		private void topBottomSolidToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.TopBottom, BorderLineStyle.Solid);
		}
		private void topBottomBoldToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.TopBottom, BorderLineStyle.BoldSolid);
		}
		private void topBottomDotToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.TopBottom, BorderLineStyle.Dotted);
		}
		private void topBottomDashToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.TopBottom, BorderLineStyle.Dashed);
		}
		#endregion

		#region All Borders
		private void allSolidToolStripSplitButton_ButtonClick(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.All, BorderLineStyle.Solid);
		}
		private void allSolidToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.All, BorderLineStyle.Solid);
		}
		private void allBoldToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.All, BorderLineStyle.BoldSolid);
		}
		private void allDottedToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.All, BorderLineStyle.Dotted);
		}
		private void allDashedToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.All, BorderLineStyle.Dashed);
		}
		#endregion

		#region Left Border
		private void leftSolidToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.Left, BorderLineStyle.Solid);
		}

		private void leftSolidToolStripButton_ButtonClick(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.Left, BorderLineStyle.Solid);
		}

		private void leftBoldToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.Left, BorderLineStyle.BoldSolid);
		}

		private void leftDotToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.Left, BorderLineStyle.Dotted);
		}

		private void leftDashToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.Left, BorderLineStyle.Dashed);
		}
		#endregion

		#region Top Border
		private void topSolidToolStripButton_ButtonClick(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.Top, BorderLineStyle.Solid);
		}

		private void topSolidToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.Top, BorderLineStyle.Solid);
		}

		private void topBlodToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.Top, BorderLineStyle.BoldSolid);
		}

		private void topDotToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.Top, BorderLineStyle.Dotted);
		}

		private void topDashToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.Top, BorderLineStyle.Dashed);
		}
		#endregion

		#region Bottom Border
		private void bottomToolStripButton_ButtonClick(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.Bottom, BorderLineStyle.Solid);
		}

		private void bottomSolidToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.Bottom, BorderLineStyle.Solid);
		}

		private void bottomBoldToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.Bottom, BorderLineStyle.BoldSolid);
		}

		private void bottomDotToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.Bottom, BorderLineStyle.Dotted);
		}

		private void bottomDashToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.Bottom, BorderLineStyle.Dashed);
		}
		#endregion

		#region Right Border
		private void rightSolidToolStripButton_ButtonClick(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.Right, BorderLineStyle.Solid);
		}

		private void rightSolidToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.Right, BorderLineStyle.Solid);
		}

		private void rightBoldToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.Right, BorderLineStyle.BoldSolid);
		}

		private void rightDotToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.Right, BorderLineStyle.Dotted);
		}

		private void rightDashToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.Right, BorderLineStyle.Dashed);
		}
		#endregion

		#region Slash
		private void slashRightSolidToolStripButton_ButtonClick(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.Slash, BorderLineStyle.Solid);
		}

		private void slashRightSolidToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.Slash, BorderLineStyle.Solid);
		}

		private void slashRightBoldToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.Slash, BorderLineStyle.BoldSolid);
		}

		private void slashRightDotToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.Slash, BorderLineStyle.Dotted);
		}

		private void slashRightDashToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.Slash, BorderLineStyle.Dashed);
		}
		#endregion

		#region Backslash
		private void slashLeftSolidToolStripButton_ButtonClick(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.Backslash, BorderLineStyle.Solid);
		}

		private void slashLeftSolidToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.Backslash, BorderLineStyle.Solid);
		}

		private void slashLeftBoldToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.Backslash, BorderLineStyle.BoldSolid);
		}

		private void slashLeftDotToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.Backslash, BorderLineStyle.Dotted);
		}

		private void slashLeftDashToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SetSelectionBorder(BorderPositions.Backslash, BorderLineStyle.Dashed);
		}
		#endregion

		#region Clear Borders
		private void clearBordersToolStripButton_Click(object sender, EventArgs e)
		{
			this.grid.DoAction(new SetRangeBorderAction(this.CurrentWorksheet.SelectionRange, BorderPositions.All,
				new BorderStyle { Color = Color.Empty, Style = BorderLineStyle.None }));
		}
		#endregion

		#endregion

		#region Style
		private void backColorPickerToolStripButton_ColorPicked(object sender, EventArgs e)
		{
			//Color c = backColorPickerToolStripButton.SolidColor;
			//if (c.IsEmpty)
			//{
			//  workbook.DoAction(new SGRemoveRangeStyleAction(workbook.SelectionRange, PlainStyleFlag.FillColor));
			//}
			//else
			//{
			this.grid.DoAction(new SetRangeStyleAction(this.CurrentWorksheet.SelectionRange, new ReoGridStyleObject()
				{
					Flag = PlainStyleFlag.BackColor,
					BackColor = backColorPickerToolStripButton.SolidColor,
				}));
			//}
		}

		private void textColorPickToolStripItem_ColorPicked(object sender, EventArgs e)
		{
			this.grid.DoAction(new SetRangeStyleAction(this.CurrentWorksheet.SelectionRange, new ReoGridStyleObject
			{
				Flag = PlainStyleFlag.TextColor,
				TextColor = textColorPickToolStripItem.SolidColor,
			}));
		}

		private void boldToolStripButton_Click(object sender, EventArgs e)
		{
			this.grid.DoAction(new SetRangeStyleAction(this.CurrentWorksheet.SelectionRange, new ReoGridStyleObject
			{
				Flag = PlainStyleFlag.FontStyleBold,
				Bold = boldToolStripButton.Checked,
			}));
		}

		private void italicToolStripButton_Click(object sender, EventArgs e)
		{
			this.grid.DoAction(new SetRangeStyleAction(this.CurrentWorksheet.SelectionRange, new ReoGridStyleObject
			{
				Flag = PlainStyleFlag.FontStyleItalic,
				Italic = italicToolStripButton.Checked,
			}));
		}

		private void underlineToolStripButton_Click(object sender, EventArgs e)
		{
			this.grid.DoAction(new SetRangeStyleAction(this.CurrentWorksheet.SelectionRange, new ReoGridStyleObject
			{
				Flag = PlainStyleFlag.FontStyleUnderline,
				Underline = underlineToolStripButton.Checked,
			}));
		}

		private void strikethroughToolStripButton_Click(object sender, EventArgs e)
		{
			this.grid.DoAction(new SetRangeStyleAction(this.CurrentWorksheet.SelectionRange, new ReoGridStyleObject
			{
				Flag = PlainStyleFlag.FontStyleStrikethrough,
				Strikethrough = strikethroughToolStripButton.Checked,
			}));
		}

		private void styleBrushToolStripButton_Click(object sender, EventArgs e)
		{
			this.CurrentWorksheet.StartPickRangeAndCopyStyle();
		}

		private void enlargeFontToolStripButton_Click(object sender, EventArgs e)
		{
			this.grid.DoAction(new StepRangeFontSizeAction(this.CurrentWorksheet.SelectionRange, true));
			UpdateMenuAndToolStrips();
		}

		private void fontSmallerToolStripButton_Click(object sender, EventArgs e)
		{
			this.grid.DoAction(new StepRangeFontSizeAction(this.CurrentWorksheet.SelectionRange, false));
			UpdateMenuAndToolStrips();
		}

		private void fontToolStripComboBox_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (isUIUpdating) return;

			this.grid.DoAction(new SetRangeStyleAction(this.CurrentWorksheet.SelectionRange, new ReoGridStyleObject
			{
				Flag = PlainStyleFlag.FontName,
				FontName = fontToolStripComboBox.Text,
			}));
		}

		private void fontSizeToolStripComboBox_TextChanged(object sender, EventArgs e)
		{
			SetGridFontSize();
		}

		private void SetGridFontSize()
		{
			if (isUIUpdating) return;

			float size = 9;
			float.TryParse(fontSizeToolStripComboBox.Text, out size);

			if (size <= 0) size = 1f;

			this.grid.DoAction(new SetRangeStyleAction(this.CurrentWorksheet.SelectionRange, new ReoGridStyleObject
			{
				Flag = PlainStyleFlag.FontSize,
				FontSize = size,
			}));
		}

		#endregion

		#region Cell & Range
		private void MergeSelectionRange(object sender, EventArgs e)
		{
			try
			{
				this.grid.DoAction(new MergeRangeAction(this.CurrentWorksheet.SelectionRange));
			}
			catch (RangeTooSmallException) { }
			catch (RangeIntersectionException)
			{
				MessageBox.Show("Specified range intersects with another one. Operation cannot be performmed.",
					Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
		}

		private void UnmergeSelectionRange(object sender, EventArgs e)
		{
			this.grid.DoAction(new UnmergeRangeAction(this.CurrentWorksheet.SelectionRange));
		}

		void resizeToolStripMenuItem_Click(object sender, EventArgs e)
		{
			var worksheet = this.CurrentWorksheet;

			using (var rgf = new ResizeGridDialog())
			{
				rgf.Rows = worksheet.RowCount;
				rgf.Cols = worksheet.ColumnCount;

				if (rgf.ShowDialog() == System.Windows.Forms.DialogResult.OK)
				{
					WorksheetActionGroup ag = new WorksheetActionGroup();

					if (rgf.Rows < worksheet.RowCount)
					{
						ag.Actions.Add(new RemoveRowsAction(rgf.Rows, worksheet.RowCount - rgf.Rows));
					}
					else if (rgf.Rows > worksheet.RowCount)
					{
						ag.Actions.Add(new InsertRowsAction(worksheet.RowCount, rgf.Rows - worksheet.RowCount));
					}

					if (rgf.Cols < worksheet.ColumnCount)
					{
						ag.Actions.Add(new RemoveColumnsAction(rgf.Cols, worksheet.ColumnCount - rgf.Cols));
					}
					else if (rgf.Cols > worksheet.ColumnCount)
					{
						ag.Actions.Add(new InsertColumnsAction(worksheet.ColumnCount, rgf.Cols - worksheet.ColumnCount));
					}

					if (ag.Actions.Count > 0)
					{
						Cursor = Cursors.WaitCursor;

						try
						{
							this.grid.DoAction(ag);
						}
						finally
						{
							Cursor = Cursors.Default;
						}
					}
				}
			}
		}
		#endregion

		#region Context Menu
		private void insertColToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (this.CurrentSelectionRange.Cols >= 1)
			{
				this.grid.DoAction(new InsertColumnsAction(CurrentSelectionRange.Col, CurrentSelectionRange.Cols));
			}
		}
		private void insertRowToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (this.CurrentSelectionRange.Rows >= 1)
			{
				this.grid.DoAction(new InsertRowsAction(CurrentSelectionRange.Row, CurrentSelectionRange.Rows));
			}
		}
		private void deleteColumnToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (this.CurrentSelectionRange.Cols >= 1)
			{
				this.grid.DoAction(new RemoveColumnsAction(CurrentSelectionRange.Col, CurrentSelectionRange.Cols));
			}
		}
		private void deleteRowsToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (this.CurrentSelectionRange.Rows >= 1)
			{
				this.grid.DoAction(new RemoveRowsAction(CurrentSelectionRange.Row, CurrentSelectionRange.Rows));
			}
		}
		private void resetToDefaultWidthToolStripMenuItem_Click(object sender, EventArgs e)
		{
			this.grid.DoAction(new SetColsWidthAction(CurrentSelectionRange.Col, CurrentSelectionRange.Cols, Worksheet.InitDefaultColumnWidth));
		}
		private void resetToDefaultHeightToolStripMenuItem_Click(object sender, EventArgs e)
		{
			this.grid.DoAction(new SetRowsHeightAction(CurrentSelectionRange.Row, CurrentSelectionRange.Rows, Worksheet.InitDefaultRowHeight));
		}
		#endregion

		#region Debug Form
#if DEBUG
        //private DebugForm cellDebugForm = null;
        //private DebugForm borderDebugForm = null;

		private void showDebugFormToolStripButton_Click(object sender, EventArgs e)
		{
            //if (cellDebugForm == null)
            //{
            //    cellDebugForm = new DebugForm();
            //    cellDebugForm.VisibleChanged += (ss, se) => showDebugFormToolStripButton.Checked = cellDebugForm.Visible;
            //}
            //else if (cellDebugForm.Visible)
            //{
            //    cellDebugForm.Visible = false;
            //    borderDebugForm.Visible = false;
            //    return;
            //}

            //cellDebugForm.Grid = this.CurrentWorksheet;

            //if (!cellDebugForm.Visible)
            //{
            //    cellDebugForm.InitTabType = DebugForm.InitTab.Grid;
            //    cellDebugForm.Show(this);
            //}

            //if (borderDebugForm == null)
            //{
            //    borderDebugForm = new DebugForm();
            //    borderDebugForm.Grid = this.CurrentWorksheet;
            //}

            //if (!borderDebugForm.Visible)
            //{
            //    borderDebugForm.InitTabType = DebugForm.InitTab.Border;
            //    borderDebugForm.Show(this);
            //}

            //if (cellDebugForm.Visible || borderDebugForm.Visible) ResetDebugFormLocation();
		}
#endif // DEBUG

		protected override void OnShown(EventArgs e)
		{
			base.OnShown(e);
		}

		protected override void OnMove(EventArgs e)
		{
			base.OnMove(e);

#if DEBUG
			ResetDebugFormLocation();
#endif // DEBUG
		}

#if DEBUG
		private void ResetDebugFormLocation()
		{
            //if (cellDebugForm != null && cellDebugForm.Visible)
            //{
            //    cellDebugForm.Location = new Point(this.Right, this.Top);
            //}
            //if (borderDebugForm != null && borderDebugForm.Visible)
            //{
            //    borderDebugForm.Location = new Point(cellDebugForm.Left, cellDebugForm.Bottom);
            //}
		}
#endif // DEBUG
		#endregion

		#region Editing
		private void cutRangeToolStripMenuItem_Click(object sender, EventArgs e)
		{
			Cut();
		}
		private void copyRangeToolStripMenuItem_Click(object sender, EventArgs e)
		{
			Copy();
		}
		private void pasteRangeToolStripMenuItem_Click(object sender, EventArgs e)
		{
			Paste();
		}

		private void Cut()
		{
			// Cut method will always perform action to do cut
			try
			{
				this.CurrentWorksheet.Cut();
			}
			catch (RangeIntersectionException)
			{
				MessageBox.Show("Cannot cut a range that is a part of another merged cell.");
			}
			catch
			{
				MessageBox.Show("We can't to do that for selected range.");
			}
		}

		private void Copy()
		{
			try
			{
				this.CurrentWorksheet.Copy();
			}
			catch (RangeIntersectionException)
			{
				MessageBox.Show("Cannot copy a range that is a part of another merged cell.");
			}
			catch
			{
				MessageBox.Show("We can't to do that for selected range.");
			}
		}

		private void Paste()
		{
			try
			{
				this.CurrentWorksheet.Paste();
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}
		#endregion

		#region Window
		private void exitToolStripMenuItem_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void newWindowToolStripMenuItem_Click(object sender, EventArgs e)
		{
			new ReoGridEditor().Show();
		}

		private void styleEditorToolStripMenuItem_Click(object sender, EventArgs e)
		{
			ControlAppearanceEditorForm styleEditor = new ControlAppearanceEditorForm();
			styleEditor.Grid = this.grid;
			styleEditor.Show(this);
		}
		#endregion

		#region Edit
		private void cutToolStripMenuItem_Click(object sender, EventArgs e)
		{
			cutToolStripButton.PerformClick();
		}

		private void copyToolStripMenuItem_Click(object sender, EventArgs e)
		{
			copyToolStripButton.PerformClick();
		}

		private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
		{
			pasteToolStripButton.PerformClick();
		}

		private void repeatLastActionToolStripMenuItem_Click(object sender, EventArgs e)
		{
			this.grid.RepeatLastAction(this.CurrentWorksheet.SelectionRange);
		}

		private void selectAllToolStripMenuItem_Click(object sender, EventArgs e)
		{
			this.CurrentWorksheet.SelectAll();
		}

		#endregion

		#region View & Print

		private void formatCellToolStripMenuItem_Click(object sender, EventArgs e)
		{
			using (PropertyForm form = new PropertyForm(this.grid))
			{
				form.ShowDialog(this);
			}
		}

		private void printPreviewToolStripMenuItem_Click(object sender, EventArgs e)
		{
			printPreviewToolStripButton.PerformClick();
		}

		private void printPreviewToolStripButton_Click(object sender, EventArgs e)
		{
			try
			{
				this.grid.CurrentWorksheet.AutoSplitPage();

				this.grid.CurrentWorksheet.EnableSettings(WorksheetSettings.View_ShowPageBreaks);
			}
			catch (Exception ex)
			{
				MessageBox.Show(this, ex.Message, Application.ProductName + " " + Application.ProductVersion,
					MessageBoxButtons.OK, MessageBoxIcon.Information);
				return;
			}

			using (var doc = this.grid.CurrentWorksheet.CreatePrintDocument())
			{
				using (PrintPreviewDialog ppd = new PrintPreviewDialog())
				{
					ppd.Document = doc;
					ppd.SetBounds(200, 200, 1024, 768);
					ppd.PrintPreviewControl.Zoom = 1d;
					ppd.ShowDialog(this);
				}
			}
		}

		void removeRowPageBreakToolStripMenuItem_Click(object sender, EventArgs e)
		{
			this.grid.CurrentWorksheet.RemoveRowPageBreak(this.grid.CurrentWorksheet.FocusPos.Row);
		}

		void removeColPageBreakToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				this.grid.CurrentWorksheet.RemoveColumnPageBreak(this.grid.CurrentWorksheet.FocusPos.Col);
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		void insertRowPageBreakToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				this.CurrentWorksheet.RowPageBreakIndexes.Add(this.CurrentWorksheet.FocusPos.Row);
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		void insertColPageBreakToolStripMenuItem_Click(object sender, EventArgs e)
		{
			this.CurrentWorksheet.ColumnPageBreakIndexes.Add(this.CurrentWorksheet.FocusPos.Col);
		}

		#endregion

		#region Freeze

		private void FreezeToEdge(FreezePosition freezePos)
		{
			var worksheet = this.CurrentWorksheet;

			if (!worksheet.SelectionRange.IsEmpty)
			{
				worksheet.FreezeToCell(worksheet.FocusPos, freezePos);
				UpdateMenuAndToolStrips();
			}
		}

		private void unfreezeToolStripMenuItem_Click(object sender, EventArgs e)
		{
			this.CurrentWorksheet.Unfreeze();
			UpdateMenuAndToolStrips();
		}

		#endregion

		#region Help
		private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
		{
			new AboutForm().ShowDialog(this);
		}
		#endregion

		#region Outline

		void groupRowsToolStripMenuItem_Click(object sender, EventArgs e)
		{
			var worksheet = this.CurrentWorksheet;

			try
			{
				worksheet.AddOutline(RowOrColumn.Row, worksheet.SelectionRange.Row, worksheet.SelectionRange.Rows);
			}
			catch (OutlineOutOfRangeException)
			{
				MessageBox.Show("Outline out of available range. The last row of spreadsheet cannot be grouped into outlines.");
			}
			catch (OutlineAlreadyDefinedException)
			{
				MessageBox.Show("Another same outline already exists.");
			}
			catch (OutlineIntersectedException)
			{
				MessageBox.Show("The outline to be added intersects with another existing one.");
			}
			catch (OutlineTooMuchException)
			{
				MessageBox.Show("Level of outlines reached the maximum number of levels (10).");
			}
		}

		void ungroupRowsToolStripMenuItem_Click(object sender, EventArgs e)
		{
			var worksheet = this.CurrentWorksheet;

			IReoGridOutline outline = null;

			try
			{
				outline = worksheet.RemoveOutline(RowOrColumn.Row, worksheet.SelectionRange.Row, worksheet.SelectionRange.Rows);
			}
			catch { }

			if (outline == null)
			{
				MessageBox.Show("No grouped rows and outline found at specified position.");
			}
		}

		void groupColumnsToolStripMenuItem_Click(object sender, EventArgs e)
		{
			var worksheet = this.CurrentWorksheet;

			try
			{
				worksheet.AddOutline(RowOrColumn.Column, worksheet.SelectionRange.Col, worksheet.SelectionRange.Cols);
			}
			catch (OutlineOutOfRangeException)
			{
				MessageBox.Show("Outline out of available range. The last column of spreadsheet cannot be grouped into outlines.");
			}
			catch (OutlineAlreadyDefinedException)
			{
				MessageBox.Show("Another outline which same as selected one has already exist.");
			}
			catch (OutlineIntersectedException)
			{
				MessageBox.Show("The outline to be added intersects with another existing one.");
			}
			catch (OutlineTooMuchException)
			{
				MessageBox.Show("Level of outlines reached the maximum number of levels (10).");
			}
		}

		void ungroupColumnsToolStripMenuItem_Click(object sender, EventArgs e)
		{
			var worksheet = this.CurrentWorksheet;

			IReoGridOutline outline = null;

			try
			{
				outline = worksheet.RemoveOutline(RowOrColumn.Column, worksheet.SelectionRange.Col, worksheet.SelectionRange.Cols);
			}
			catch { }

			if (outline == null)
			{
				MessageBox.Show("No grouped columns and outline found at specified position.");
			}
		}

		void ungroupAllRowsToolStripMenuItem_Click(object sender, EventArgs e)
		{
			this.CurrentWorksheet.UngroupAllRows();
		}

		void ungroupAllColumnsToolStripMenuItem_Click(object sender, EventArgs e)
		{
			this.CurrentWorksheet.UngroupAllColumns();
		}

		#endregion

		#region Filter
		private AutoColumnFilter columnFilter;

		void filterToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (this.columnFilter != null)
			{
				this.columnFilter.Detach();
			}

			CreateAutoFilterAction action = new CreateAutoFilterAction(this.CurrentWorksheet.SelectionRange);
			this.grid.DoAction(action);

			this.columnFilter = action.AutoColumnFilter;
		}

		void clearFilterToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (this.columnFilter != null)
			{
				columnFilter.Detach();
			}
		}
		#endregion // Filter

#if DEBUG
		private void ForTest()
		{
		}
#endif
	}

}

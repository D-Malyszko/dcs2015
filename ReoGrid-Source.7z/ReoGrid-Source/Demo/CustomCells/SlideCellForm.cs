﻿/*****************************************************************************
 * 
 * ReoGrid - .NET Spreadsheet Control
 * 
 * http://reogrid.net
 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
 * KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
 * PURPOSE.
 *
 * ReoGrid Demo project released under BSD license.
 * 
 * Author: Jing Lu <lujing at unvell.com>
 * Copyright (c) 2012-2015 unvell.com, all rights reserved.
 * 
 ****************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using unvell.ReoGrid.CellTypes;
using unvell.ReoGrid.Events;

namespace unvell.ReoGrid.Demo.CustomCells
{
	public partial class SlideCellForm : Form
	{
		private Worksheet worksheet;

		public SlideCellForm()
		{
			InitializeComponent();

			worksheet = grid.CurrentWorksheet;

			chkShowGridLines.CheckedChanged += (s, e) =>
				worksheet.SetSettings(WorksheetSettings.View_ShowGridLine, chkShowGridLines.Checked);

			chkDisableSelection.CheckedChanged += (s, e) =>
				worksheet.SelectionMode = chkDisableSelection.Checked ?
				ReoGridSelectionMode.None : ReoGridSelectionMode.Range;
		}

		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad(e);

			worksheet.ColumnHeaders[2].WidthInPixel = 100;
			worksheet.ColumnHeaders[4].WidthInPixel = 120;

			worksheet[4, 4] = new SlideCell();
			worksheet[4, 4] = 50;
			worksheet[4, 3] = "=E5&\"%\"";

			worksheet[7, 4] = new SlideCell();
			worksheet[7, 4] = 50;
			worksheet[7, 2] = new NumericProgressCell();
			worksheet[7, 2] = "=E8";
			worksheet[7, 3] = "=E8&\"%\"";

			worksheet[6, 2] = "bind by '=E8'";
			worksheet[2, 3] = "Try slide the green thumb below...";

			// link
			worksheet.MergeRange(12, 0, 1, 7);
			worksheet[11, 0] = "More info about Custom Cell:";
			worksheet[12, 0] = new unvell.ReoGrid.CellTypes.HyperlinkCell(
				"http://reogrid.net/document/Custom%20Cell", true);
		}
	}

	public class SlideCell : CellBody
	{
		// hold the instance of grid control
		public Worksheet Worksheet { get; set; }

		public override void OnSetup(Worksheet sheet, ReoGridCell cell)
		{
			this.Worksheet = sheet;
		}

		public bool IsHover { get; set; }

		public override void OnPaint(RGDrawingContext dc)
		{
			// try getting the cell value
			float value = 0;
			float.TryParse(dc.Cell.Display, out value);

			// retrieve graphics object
			var g = dc.Graphics;

			int halfHeight = Bounds.Height / 2;
			int sliderHeight = Math.Min(Bounds.Height - 4, 20);

			// draw slide bar
			g.FillRectangle(Brushes.Gainsboro, 4, halfHeight - 3, Bounds.Width - 8, 6);

			int x = 2 + (int)Math.Round(value / 100f * (Bounds.Width - 12));

			// thumb rectangle
			Rectangle rect = new Rectangle(x, halfHeight - sliderHeight / 2, 8, sliderHeight);

			// draw slide thumb
			g.FillRectangle(IsHover ? Brushes.LimeGreen : Brushes.LightGreen, rect);
		}

		public override bool OnMouseDown(CellMouseEventArgs e)
		{
			UpdateValueByCursorX(e.CellPosition, e.RelativePosition.X);

			// return true to notify control that the mouse-down operation has been hanlded.
			// all operations after this will be aborted.
			return true;
		}

		public override bool OnMouseMove(CellMouseEventArgs e)
		{
			// requires the left button
			if (e.Buttons == unvell.ReoGrid.Views.MouseButtons.Left)
			{
				UpdateValueByCursorX(e.CellPosition, e.RelativePosition.X);
			}

			return false;
		}

		private void UpdateValueByCursorX(ReoGridPos cellPos, int x)
		{
			// calcutate value by cursor position
			int value = (int)Math.Round(x * 100f / (Bounds.Width - 2f));

			if (value < 0) value = 0;
			if (value > 100) value = 100;

			Worksheet.SetCellData(cellPos, value);
		}

		public override bool OnMouseEnter(CellMouseEventArgs e)
		{
			IsHover = true;
			return true;
		}

		public override bool OnMouseLeave(CellMouseEventArgs e)
		{
			IsHover = false;
			return true;		
		}

		public override bool OnStartEdit(ReoGridCell cell)
		{
			// disable editing on this cell
			return false;
		}
	}

}

﻿/*****************************************************************************
 * 
 * ReoGrid - .NET Spreadsheet Control
 * 
 * http://reogrid.net
 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
 * KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
 * PURPOSE.
 *
 * ReoGrid Demo project released under BSD license.
 * 
 * Author: Jing Lu <lujing at unvell.com>
 * Copyright (c) 2012-2015 unvell.com, all rights reserved.
 * 
 ****************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using unvell.ReoGrid.CellTypes;
using unvell.ReoGrid.Demo.Properties;

namespace unvell.ReoGrid.Demo.CustomCells
{
	public partial class AnimationCellForm : Form
	{
		// timer to update animation frames intervally
		Timer timer = new Timer();
		
		private LoadingCell loadingCell;

		private GifImageCell gifCell;

		private Worksheet worksheet;

		public AnimationCellForm()
		{
			InitializeComponent();

			// prepare timer to udpate sheet
			timer.Interval = 10;
			timer.Tick += timer_Tick;

			// get default worksheet
			worksheet = grid.CurrentWorksheet;

			// change cells size
			worksheet.SetRowsHeight(5, 1, 100);
			worksheet.SetColumnsWidth(1, 5, 100);

			worksheet.SetRangeStyle(3, 1, 5, 5, new ReoGridStyleObject
			{
				Flag = PlainStyleFlag.HorizontalAlign | PlainStyleFlag.VerticalAlign,
				HAlign = ReoGridHorAlign.Center,
				VAlign = ReoGridVerAlign.Middle,
			});

			// waiting cell
			loadingCell = new LoadingCell();
			worksheet[3, 1] = loadingCell;

			// gif image cell
			gifCell = new GifImageCell(Resources.loading);
			worksheet[5, 2] = gifCell;

			// gif image cell
			worksheet[5, 4] = new BlinkCell();
			worksheet[5, 4] = "Blink Cell";

			// note text
			worksheet[7, 1] = "NOTE: Too many updates during animation will affect the rendering performance.";
			worksheet.SetRangeStyle(7, 1, 1, 1, new ReoGridStyleObject
			{
				Flag = PlainStyleFlag.TextColor | PlainStyleFlag.BackColor,
				BackColor = Color.Orange,
				TextColor = Color.White,
			});
			worksheet.MergeRange(7, 1, 1, 6);
		}

		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad(e);

			timer.Start();
		}

		void timer_Tick(object sender, EventArgs e)
		{
			// update frame
			loadingCell.NextFrame();

			// sample: retrieve body from cell
			var cell = worksheet.Cells[5, 4];
			if (cell.Body is BlinkCell)
			{
				((BlinkCell)cell.Body).NextFrame();
			}

			// repaint control
			worksheet.InvalidateSheet();
		}

		protected override void OnClosing(CancelEventArgs e)
		{
			base.OnClosing(e);

			timer.Stop();
			timer.Dispose();
		}
	}

	class LoadingCell : CellBody
	{
		public LoadingCell()
		{
			ThumbSize = 30;
			StepSize = 1;
		}

		public void NextFrame()
		{
			if (dir > 0)
			{
				offset += StepSize;
				if (offset >= Bounds.Width - ThumbSize - StepSize) dir = -1;
			}
			else
			{
				offset -= StepSize;
				if (offset <= 0) dir = 1;
			}
		}

		private int offset = 0;
		private int dir = 1;

		public int ThumbSize { get; set; }
		public int StepSize { get; set; }

		public override void OnPaint(RGDrawingContext dc)
		{
			dc.Graphics.FillRectangle(Brushes.SkyBlue, new Rectangle(offset, 0, ThumbSize, Bounds.Height));

			// call core text draw
			dc.DrawCellText();
		}
	}

	class GifImageCell : CellBody
	{
		public Image Gif { get; set; }

		public GifImageCell(Image gif)
		{
			this.Gif = gif;
		}

		public override void OnSetup(Worksheet sheet, ReoGridCell cell)
		{
			ImageAnimator.Animate(Gif, OnFrameChanged);
		}

		private void OnFrameChanged(object o, EventArgs e)
		{
			lock (this.Gif) ImageAnimator.UpdateFrames(Gif);
		}

		public override void OnPaint(RGDrawingContext dc)
		{
			lock (this.Gif) dc.Graphics.DrawImage(Gif, Bounds);

			// call core text draw
			dc.DrawCellText();
		}
	}

	class BlinkCell : CellBody
	{
		public BlinkCell()
		{
			StepSize = 2;
		}

		public void NextFrame()
		{
			if (dir > 0)
			{
				alpha += StepSize;
				if (alpha >= 100) dir = -1;
			}
			else
			{
				alpha -= StepSize;
				if (alpha <= 0) dir = 1;
			}
		}

		private int alpha = 0;
		private int dir = 1;

		public int StepSize { get; set; }

		public override void OnPaint(RGDrawingContext dc)
		{
			using (var b = new SolidBrush(Color.FromArgb(alpha, Color.Orange)))
			{
				dc.Graphics.FillRectangle(b, Bounds);
			}

			// call core text draw
			dc.DrawCellText();
		}
	}

}

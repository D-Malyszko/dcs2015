﻿/*****************************************************************************
 * 
 * ReoGrid - .NET Spreadsheet Control
 * 
 * http://reogrid.net
 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
 * KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
 * PURPOSE.
 *
 * ReoGrid Demo project released under BSD license.
 * 
 * Author: Jing Lu <lujing at unvell.com>
 * Copyright (c) 2012-2015 unvell.com, all rights reserved.
 * 
 ****************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace unvell.ReoGrid.Demo
{
	public partial class GridForm : Form
	{
		public GridForm()
		{
			InitializeComponent();
		}

		public void Open(string file, Action<Worksheet> postHandler = null)
		{
#if DEBUG
			grid.Load(System.IO.Path.Combine("..\\..\\..\\Samples", file));
#else
			grid.Load(file);
#endif

			this.PostHandler = postHandler;
		}

		public void Init(Action<Worksheet> postHandler)
		{
			this.PostHandler = postHandler;
		}

		public Action<Worksheet> PostHandler { get; set; }

		protected override void OnCreateControl()
		{
			base.OnCreateControl();

			if (this.PostHandler != null) PostHandler(grid.CurrentWorksheet);
		}
	}
}

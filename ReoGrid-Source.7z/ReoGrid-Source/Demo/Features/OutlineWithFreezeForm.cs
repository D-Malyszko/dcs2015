﻿/*****************************************************************************
 * 
 * ReoGrid - .NET Spreadsheet Control
 * 
 * http://reogrid.net
 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
 * KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
 * PURPOSE.
 *
 * ReoGrid Demo project released under BSD license.
 * 
 * Author: Jing Lu <lujing at unvell.com>
 * Copyright (c) 2012-2015 unvell.com, all rights reserved.
 * 
 ****************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace unvell.ReoGrid.Demo.Other
{
	public partial class OutlineWithFreezeForm : Form
	{
		public OutlineWithFreezeForm()
		{
			InitializeComponent();

			var worksheet = grid.CurrentWorksheet;

			for (int i = 1; i < 9; i++)
			{
				worksheet.AddOutline(RowOrColumn.Row, 4, i);
			}
			for (int i = 1; i < 9; i++)
			{
				worksheet.AddOutline(RowOrColumn.Column, 2, i);
			}

			worksheet.FreezeToCell(5, 5);

			worksheet[2, 2] = "This is sample of frozen outlines.";
		}
	}
}

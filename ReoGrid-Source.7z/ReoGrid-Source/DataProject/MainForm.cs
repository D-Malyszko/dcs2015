﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using unvell.ReoGrid;


namespace DataProject
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();

            sp = splitContainer1;

            LoadMainForm();

            addview(reo);

            LoadRichTextBox();

            addview(res);
        }

        public unvell.ReoGrid.Editor.ReoGridEditor reo { get; set; }

        public SplitContainer sp { get; set; }

        public RichTextBox res { get; set; }

        public void LoadMainForm()
        {
            try
            {
                Cursor = Cursors.Default;




                reo = new unvell.ReoGrid.Editor.ReoGridEditor();

                reo.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;

                reo.Dock = DockStyle.Fill;

                reo.TopMost = false;

                reo.TopLevel = false;

                sp.Panel2.Controls.Add(reo);

                reo.Show();


                
                


            }
            finally
            {
                Cursor = Cursors.Default;
            }
        }

        public void LoadRichTextBox()
        {

            res = new RichTextBox();
            res.Dock = DockStyle.Fill;

            sp.Panel2.Controls.Add(res);



        }

       
           static public void toggle(Control c){


               if(c.Visible == true)
                   c.Visible = false;
               else
                   c.Visible = true;

               

        }


           public ArrayList views { get; set; }

           public int act = 0;

           public void togglec(Control c, Control p)
           {

               foreach (Control cc in views)
               {
                   if (cc == c)
                   {

                       p.Controls.Add(cc);

                   }
                   else
                   {
                       p.Controls.Remove(cc);

                   }


               }

           }


           public void next(ArrayList views, Control p)
           {

               if (act >= views.Count - 1)
                   act = 0;
               else
                   act++;

               Control c = views[act] as Control;

               int i = 0;

               foreach (Control cc in views)
               {
                   if (cc == c)
                   {

                       p.Controls.Add(cc);
                       act = i;
                   }
                   else
                   {
                       p.Controls.Remove(cc);

                   }

                   i++;
               }

           }

        public void addview(Control c){

            if (views == null)
            {
                act = 0;
                views = new ArrayList();
            }

            views.Add(c);
            act = views.Count - 1;
        }


        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            toggle(reo.MainMenuStrip);
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            if (reo == null)
                return;

            reo.toggletools();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            toggle_sp(sp);
        }

        public static void toggle_sp(SplitContainer sp)
        {

            if (sp.Panel1Collapsed == true)
            {

                sp.Panel1Collapsed = false;
                sp.Panel2Collapsed = false;

            }
            else if(sp.Panel2Collapsed == false)
            {

                sp.Panel2Collapsed = true;
                sp.Panel1Collapsed = false;

            }
            else
            {

                sp.Panel1Collapsed = true;
                sp.Panel2Collapsed = false;


            }

        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            next(views, sp.Panel2);
        }

        public string file = "data\\ReoGridEditor.Designer.cs";
        private void button1_Click(object sender, EventArgs e)
        {

            string []s = File.ReadAllLines(file);


            var ws = reo.GridControl.Worksheets;

            if(ws == null)
                return;

            int i = ws.Count;

            var w = ws[0];

            w.SetColumnsWidth(1, 1000, 20);

            int r = 1;

            int c = 1;

            foreach(string text in s) {


                c = 0;

                //w.GetCell(r, c).Data = "a" ;

                foreach (char cc in text)
                {
                    //char output = c; // if or do with c what you need



                    

                    if (c >= w.Columns)
                    {

                        w.Columns *= 2;

                    }
                    if (r >= w.RowCount)
                    {

                        w.RowCount *= 2;

                    }




                    ReoGridCell rc = w.GetCell(r, c);

                    if (rc == null)
                        rc = w.CreateAndGetCell(r, c);



                    rc.Data = cc.ToString();

                    c++;
                }

                r++;
            }

        }

    }


}



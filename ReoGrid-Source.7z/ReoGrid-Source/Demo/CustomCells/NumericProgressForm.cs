﻿/*****************************************************************************
 * 
 * ReoGrid - .NET Spreadsheet Control
 * 
 * http://reogrid.net
 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
 * KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
 * PURPOSE.
 *
 * ReoGrid Demo project released under BSD license.
 * 
 * Author: Jing Lu <lujing at unvell.com>
 * Copyright (c) 2012-2015 unvell.com, all rights reserved.
 * 
 ****************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using unvell.ReoGrid.CellTypes;

namespace unvell.ReoGrid.Demo.CustomCells
{
	public partial class NumericProgressForm : Form
	{
		private Worksheet worksheet;

		public NumericProgressForm()
		{
			InitializeComponent();

			this.worksheet = grid.CurrentWorksheet;

			var rand = new Random();

			worksheet[1, 2] = "Try change the value below: ";

			for (int r = 3; r <= 7; r++)
			{
				// set the cell with customized body
				worksheet.SetCellBody(r, 2, new NumericProgressCell());

				// set formula into cell which is used to get data from right side cell
				worksheet[r, 2] = "=100 * " + new ReoGridPos(r, 3).ToAddress(); // e.g. D3

				// set data format as percent
				worksheet.SetRangeDataFormat(r, 3, 1, 1, DataFormat.CellDataFormatFlag.Percent, null);

				// generate a random value
				worksheet[r, 3] = rand.Next(100);
			}

			// change selection forward direction to down
			worksheet.SelectionForwardDirection = SelectionForwardDirection.Down;

			// put focus on cell
			worksheet.FocusPos = new ReoGridPos(3, 3);

			// link
			worksheet.MergeRange(12, 0, 1, 7);
			worksheet[11, 0] = "More info about Custom Cell:";
			worksheet[12, 0] = new HyperlinkCell(
				"http://reogrid.net/document/Custom%20Cell", true);
		}
	}

	internal class NumericProgressCell : CellBody
	{
		public override void OnPaint(RGDrawingContext dc)
		{
			int value = 0;
			int.TryParse(dc.Cell.Display, out value);

			if (value > 0)
			{
				Graphics g = dc.Graphics;

				Rectangle rect = new Rectangle(Bounds.Left, Bounds.Top + 1,
					(int)(Math.Round(Bounds.Width / 100f * value)), Bounds.Height - 1);

				using (LinearGradientBrush lgb = new LinearGradientBrush(rect, Color.Coral, Color.IndianRed, 90f))
				{
					g.PixelOffsetMode = PixelOffsetMode.Half;
					g.FillRectangle(lgb, rect);
					g.PixelOffsetMode = PixelOffsetMode.Default;
				}
			}
		}
	}
}

﻿/*****************************************************************************
 * 
 * ReoGrid - .NET Spreadsheet Control
 * 
 * http://reogrid.net/
 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
 * KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
 * PURPOSE.
 *
 * ReoGridEditor released under BSD license.
 * 
 * Author: Jing Lu <lujing at unvell.com>
 * Copyright (c) 2012-2015 unvell.com, all rights reserved.
 * 
 ****************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace unvell.ReoGrid.Editor
{
	public partial class DefineNamedRangeDialog : Form
	{
		public DefineNamedRangeDialog()
		{
			InitializeComponent();

			txtName.KeyDown += (s, e) =>
			{
				if (e.KeyCode == Keys.Enter)
				{
					btnOK.PerformClick();
				}
			};

			txtRange.KeyDown += (s, e) =>
			{
				if (e.KeyCode == Keys.Enter)
				{
					btnOK.PerformClick();
				}
			};
		}

		public string RangeName { get; set; }

		public string Comment { get; set; }

		public ReoGridRange Range { get; set; }

		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad(e);

			txtName.Text = RangeName;
			txtComment.Text = Comment;
			
			if (!Range.IsEmpty)
			{
				txtRange.Text = Range.IsSingleCell ? Range.StartPos.ToAddress() : Range.ToAddress();
			}
		}

		private void btnOK_Click(object sender, EventArgs e)
		{
			if (string.IsNullOrEmpty(txtName.Text))
			{
				MessageBox.Show("Please input the name of range.");
				txtName.Focus();
				return;
			}

			if (string.IsNullOrEmpty(txtRange.Text)
				|| !ReoGridRange.IsValidAddress(txtRange.Text))
			{
				MessageBox.Show("The address of range is invalid.");
				txtRange.Focus();
				return;
			}

			RangeName = txtName.Text;
			Comment = txtComment.Text;

			Range = new ReoGridRange(txtRange.Text);

			DialogResult = System.Windows.Forms.DialogResult.OK;
			Close();
		}
	}
}

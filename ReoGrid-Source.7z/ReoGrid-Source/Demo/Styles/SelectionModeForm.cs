﻿/*****************************************************************************
 * 
 * ReoGrid - .NET Spreadsheet Control
 * 
 * http://reogrid.net
 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
 * KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
 * PURPOSE.
 *
 * ReoGrid Demo project released under BSD license.
 * 
 * Author: Jing Lu <lujing at unvell.com>
 * Copyright (c) 2012-2015 unvell.com, all rights reserved.
 * 
 ****************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using unvell.ReoGrid.CellTypes;

namespace unvell.ReoGrid.Demo.Styles
{
	public partial class SelectionModeForm : Form
	{
		private Worksheet worksheet;

		public SelectionModeForm()
		{
			InitializeComponent();

			this.worksheet = grid.CurrentWorksheet;

			// resize spreadsheet
			worksheet.Resize(50, 7);

			// change header width
			worksheet.ColumnHeaders[0].WidthInPixel = 100;
			worksheet.ColumnHeaders[1].WidthInPixel = 500;

			// fill data
			worksheet[0, 0] = new object[,] {
				{ "Function", "Description" },
				{ "INDIRECT", "Returns the reference specified by a text string." },
				{ "ADDRESS", "You can use the ADDRESS function to obtain the address of a cell in a worksheet." },
				{ "COUNT", "The COUNT function counts the number of cells that contain numbers, and counts numbers within the list of arguments." },
				{ "COUNTIF", "The COUNTIF function counts the number of cells within a range that meet a single criterion that you specify." },
				{ "SUM", "Returns the sum of a set of values contained in a specified field on a query." },
				{ "SUMIF", "You use the SUMIF function to sum the values in a range that meet criteria that you specify." },
				{ "AVERAGE", "Returns the average (arithmetic mean) of the arguments." },
				{ "LOOKUP", "The LOOKUP function returns a value either from a one-row or one-column range or from an array." },
				{ "ROWS", "Returns the number of rows in a reference or array." },
				{ "COLUMNS", "Returns the number of columns in an array or reference." },
				{ "INDEX", "Returns a value or the reference to a value from within a table or range." },
				{ "CEILING", "Returns number rounded up, away from zero, to the nearest multiple of significance." },
				{ "LEN", "returns the number of characters in a text string." },
				{ "LENB", "returns the number of bytes used to represent the characters in a text string." },
				{ "ROUND", "Round a number to the nearest number." },
			};

			// set first row style
			worksheet.SetRangeStyle(0, 0, 1, -1, new ReoGridStyleObject
			{
				Flag = PlainStyleFlag.BackColor | PlainStyleFlag.TextColor | PlainStyleFlag.FontStyleBold,
				BackColor = Color.DarkSeaGreen,
				TextColor = Color.DarkSlateBlue,
				Bold = true,
			});

			// set cursor style for cells to default cursor
			worksheet.SelectionMode = ReoGridSelectionMode.Row;

			worksheet.SetSettings(WorksheetSettings.View_AllowCellTextOverflow, false);
		}
	}
}

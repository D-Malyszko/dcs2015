﻿/*****************************************************************************
 * 
 * ReoGrid - .NET Spreadsheet Control
 * 
 * http://reogrid.net
 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
 * KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
 * PURPOSE.
 *
 * ReoGrid Demo project released under BSD license.
 * 
 * Author: Jing Lu <lujing at unvell.com>
 * Copyright (c) 2012-2015 unvell.com, all rights reserved.
 * 
 ****************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using unvell.ReoGrid.CellTypes;
using unvell.ReoGrid.Demo.Properties;

namespace unvell.ReoGrid.Demo.CustomCells
{
	public partial class CustomDropdownForm : Form
	{
		private Worksheet worksheet;

		public CustomDropdownForm()
		{
			InitializeComponent();

			this.worksheet = grid.CurrentWorksheet;

			// set sheet default style
			worksheet.SetRangeStyle(ReoGridRange.EntireRange, new ReoGridStyleObject
			{
				Flag = PlainStyleFlag.FontName | PlainStyleFlag.VerticalAlign,
				FontName = "Arial",
				VAlign = ReoGridVerAlign.Middle,
			});

			worksheet.ColumnHeaders["B"].WidthInPixel = 120;

			worksheet["B2"] = "Choose...";
			worksheet["B2"] = new ListViewDropdownCell();
			worksheet.Ranges["B2"].BorderOutline = BorderStyle.GraySolid;

			worksheet["B5"] = "Choose...";
			worksheet["B5"] = new ListViewDropdownCell();
			worksheet.Ranges["B5"].BorderOutline = BorderStyle.GraySolid;
		}

		private void chkGridlines_CheckedChanged(object sender, EventArgs e)
		{
			worksheet.SetSettings(WorksheetSettings.View_ShowGridLine, chkGridlines.Checked);
		}

	}

	class ListViewDropdownCell : DropdownCell
	{
		private ListView listView;

		public ListViewDropdownCell()
		{
			// create listview
			this.listView = new ListView()
			{
				BorderStyle = System.Windows.Forms.BorderStyle.None,
				View = View.Details,
				FullRowSelect = true,
			};

			// set dropdown control
			this.DropdownControl = listView;

			// add listview columns
			this.listView.Columns.Add("Column 1", 120);
			this.listView.Columns.Add("Column 2", 120);

			// add groups and items
			var group1 = listView.Groups.Add("grp1", "Group 1");
			listView.Items.Add(new ListViewItem(new string[] { "Item 1.1", "Subitem 1.1" }) { Group = group1 });
			listView.Items.Add(new ListViewItem(new string[] { "Item 1.2", "Subitem 1.2" }) { Group = group1 });
			listView.Items.Add(new ListViewItem(new string[] { "Item 1.3", "Subitem 1.3" }) { Group = group1 });

			var group2 = listView.Groups.Add("grp2", "Group 2");
			listView.Items.Add(new ListViewItem(new string[] { "Item 2.1", "Subitem 2.1" }) { Group = group2 });
			listView.Items.Add(new ListViewItem(new string[] { "Item 2.2", "Subitem 2.2" }) { Group = group2 });
			listView.Items.Add(new ListViewItem(new string[] { "Item 2.3", "Subitem 2.3" }) { Group = group2 });

			// enlarge the dropdown panel
			this.MinimumDropdownWidth = 300;

			// add click event handler
			this.listView.Click += listView_Click;

		}

		void listView_Click(object sender, EventArgs e)
		{
			if (this.listView.SelectedItems.Count > 0)
			{
				this.Cell.Data = this.listView.SelectedItems[0].Text;
				PullUp();
			}
		}
	}
}

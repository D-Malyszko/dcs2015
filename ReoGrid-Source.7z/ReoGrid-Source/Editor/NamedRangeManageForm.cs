﻿/*****************************************************************************
 * 
 * ReoGrid - .NET Spreadsheet Control
 * 
 * http://reogrid.net/
 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
 * KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
 * PURPOSE.
 *
 * ReoGridEditor released under BSD license.
 * 
 * Author: Jing Lu <lujing at unvell.com>
 * Copyright (c) 2012-2015 unvell.com, all rights reserved.
 * 
 ****************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace unvell.ReoGrid.Editor
{
	public partial class NamedRangeManageForm : Form
	{
		private ReoGridControl grid;

		public NamedRangeManageForm(ReoGridControl grid)
		{
			InitializeComponent();

			this.grid = grid;
		}

		private void NamedRangeManageForm_Load(object sender, EventArgs _unused)
		{
			if (this.grid.CurrentWorksheet == null)
			{
				MessageBox.Show("No worksheet contained in current control.");
				return;
			}

			foreach (var name in this.grid.CurrentWorksheet.GetAllNamedRanges())
			{
				var range = this.grid.CurrentWorksheet.GetNamedRange(name);

				var item = new ListViewItem(new string[] { range.Name, range.Range.ToAddress() }) { Tag = range };
				this.lstRanges.Items.Add(item);
			}

			this.lstRanges.SelectedIndexChanged += (s, e) =>
				{
					if (this.lstRanges.SelectedItems.Count > 0)
					{
						var item = this.lstRanges.SelectedItems[0];
						if (item != null)
						{
							var range = item.Tag as NamedRange;
							if (range != null && range.Worksheet == this.grid.CurrentWorksheet)
							{
								this.grid.CurrentWorksheet.SelectionRange = range;
							}
						}
					}
				};
		}

		private void btnNew_Click(object sender, EventArgs e)
		{
			using (var dlg = new DefineNamedRangeDialog())
			{
				if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
				{
					NamedRange range = DefineNamedRange(this, this.grid.CurrentWorksheet,
						dlg.RangeName, dlg.Comment, dlg.Range);

					if (range != null)
					{
						lstRanges.Items.Add(new ListViewItem(new string[] { range.Name, range.Range.ToAddress() }) { Tag = range });

						if (range.Worksheet == this.grid.CurrentWorksheet)
						{
							this.grid.CurrentWorksheet.SelectionRange = range;
						}
					}
				}
			}
		}

		private void btnEdit_Click(object sender, EventArgs e)
		{
			if (this.lstRanges.SelectedItems.Count > 0)
			{
				var item = this.lstRanges.SelectedItems[0];
				var range = item.Tag as NamedRange;

				if (range != null)
				{
					using (var dlg = new DefineNamedRangeDialog())
					{
						dlg.RangeName = range.Name;
						dlg.Range = range;

						if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
						{
							range.Name = dlg.RangeName;
							range.Range = dlg.Range;
							range.Comment = dlg.Comment;

							item.Text = dlg.RangeName;
							item.SubItems[1].Text = dlg.Range.ToAddress();
							this.grid.CurrentWorksheet.SelectionRange = range;

							if (range.Worksheet == this.grid.CurrentWorksheet)
							{
								this.grid.CurrentWorksheet.SelectionRange = range;
							}
						}
					}
				}
			}
		}

		private void btnDelete_Click(object sender, EventArgs e)
		{
			if (this.lstRanges.SelectedItems.Count > 0)
			{
				var item = this.lstRanges.SelectedItems[0];
				var range = item.Tag as NamedRange;

				if (range != null)
				{
					if (MessageBox.Show(this, "Are you sure to delete selected named range?", "Delete Named Range",
						 MessageBoxButtons.YesNo, MessageBoxIcon.Information) == System.Windows.Forms.DialogResult.Yes)
					{
						if (this.grid.CurrentWorksheet.UndefineNamedRange(range.Name))
						{
							this.lstRanges.Items.Remove(item);
						}
					}
				}
			}
		}

		internal static NamedRange DefineNamedRange(IWin32Window owner, Worksheet sheet, string name, string comment, ReoGridRange range)
		{
			NamedRange namedRange = null;

			try
			{
				namedRange = sheet.DefineNamedRange(name, range);
				namedRange.Comment = comment;
			}
			catch
			{
				MessageBox.Show(owner, "Cannot define named range by specified name. Make sure:\n"
					+ "  The name does not begin with a number\n"
					+ "  The name does not contain spaces or any invalid characters\n"
					+ "  The name is not same as any address of cell and range\n"
					+ "  The name is not same as any built-in function names",
					"Error during define named range", MessageBoxButtons.OK, MessageBoxIcon.Information);
			}

			return namedRange;
		}

		private void btnClose_Click(object sender, EventArgs e)
		{
			Close();
		}

	}
}

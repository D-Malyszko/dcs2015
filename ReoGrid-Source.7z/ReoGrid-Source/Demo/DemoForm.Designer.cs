﻿/*****************************************************************************
 * 
 * ReoGrid - .NET Spreadsheet Control
 * 
 * http://reogrid.net
 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
 * KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
 * PURPOSE.
 *
 * ReoGrid Demo project released under BSD license.
 * 
 * Author: Jing Lu <lujing at unvell.com>
 * Copyright (c) 2012-2015 unvell.com, all rights reserved.
 * 
 ****************************************************************************/

namespace unvell.ReoGrid.Demo
{
	partial class DemoForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DemoForm));
			this.btnCalendarDoc = new System.Windows.Forms.Button();
			this.btnOrderDoc = new System.Windows.Forms.Button();
			this.btnProjectCostDoc = new System.Windows.Forms.Button();
			this.button4 = new System.Windows.Forms.Button();
			this.button5 = new System.Windows.Forms.Button();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.btnMazeDoc = new System.Windows.Forms.Button();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.btnCustomHeader = new System.Windows.Forms.Button();
			this.btnMergedCells = new System.Windows.Forms.Button();
			this.btnBorderStyles = new System.Windows.Forms.Button();
			this.btnCellColors = new System.Windows.Forms.Button();
			this.btnSelectionMode = new System.Windows.Forms.Button();
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.btnCustomSelection = new unvell.ReoGrid.Demo.NewLabelButton();
			this.btnMultisheet = new unvell.ReoGrid.Demo.NewLabelButton();
			this.btnFilterAndSort = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.button13 = new System.Windows.Forms.Button();
			this.button23 = new System.Windows.Forms.Button();
			this.button21 = new System.Windows.Forms.Button();
			this.btnDataFormat = new System.Windows.Forms.Button();
			this.btnMergeCells = new System.Windows.Forms.Button();
			this.btnAutoDataFormatDoc = new System.Windows.Forms.Button();
			this.button30 = new System.Windows.Forms.Button();
			this.groupBox5 = new System.Windows.Forms.GroupBox();
			this.button26 = new System.Windows.Forms.Button();
			this.button19 = new System.Windows.Forms.Button();
			this.button16 = new System.Windows.Forms.Button();
			this.button14 = new System.Windows.Forms.Button();
			this.button15 = new System.Windows.Forms.Button();
			this.groupBox6 = new System.Windows.Forms.GroupBox();
			this.button25 = new System.Windows.Forms.Button();
			this.btnCustomFunction = new unvell.ReoGrid.Demo.NewLabelButton();
			this.button17 = new System.Windows.Forms.Button();
			this.button18 = new System.Windows.Forms.Button();
			this.button22 = new System.Windows.Forms.Button();
			this.menuStrip1 = new System.Windows.Forms.MenuStrip();
			this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.randomDemoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
			this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.reportBugToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
			this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.projectHomepageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.customCellsContextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.numericProgressToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.slideCellToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.controlAppearanceContextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.goldSilverToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.lightGreenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.snowWhiteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.groupBox4 = new System.Windows.Forms.GroupBox();
			this.btnMaximumSheet = new System.Windows.Forms.Button();
			this.button12 = new System.Windows.Forms.Button();
			this.btnManyRows = new System.Windows.Forms.Button();
			this.groupBox7 = new System.Windows.Forms.GroupBox();
			this.btnCustomDropdown = new unvell.ReoGrid.Demo.NewLabelButton();
			this.button34 = new System.Windows.Forms.Button();
			this.button33 = new System.Windows.Forms.Button();
			this.button31 = new System.Windows.Forms.Button();
			this.button29 = new System.Windows.Forms.Button();
			this.button27 = new unvell.ReoGrid.Demo.DropdownButton();
			this.labVersion = new System.Windows.Forms.Label();
			this.lnkReportBug = new System.Windows.Forms.LinkLabel();
			this.groupBox8 = new System.Windows.Forms.GroupBox();
			this.btnFreezeToEdges = new unvell.ReoGrid.Demo.DropdownButton();
			this.freezeToEdgesContextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.freeToLeftToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.freezeToTopToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.freezeToRightToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.freezeToBottomToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
			this.freezeToLeftTopToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.freezeToLeftBottomToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.freezeToRightTopToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.freezeToRightBottomToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.groupBox9 = new System.Windows.Forms.GroupBox();
			this.button35 = new System.Windows.Forms.Button();
			this.button38 = new System.Windows.Forms.Button();
			this.groupBox10 = new System.Windows.Forms.GroupBox();
			this.button36 = new System.Windows.Forms.Button();
			this.btnLoadExcel = new unvell.ReoGrid.Demo.NewLabelButton();
			this.dropdownButton1 = new unvell.ReoGrid.Demo.DropdownButton();
			this.groupBox1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.groupBox3.SuspendLayout();
			this.groupBox5.SuspendLayout();
			this.groupBox6.SuspendLayout();
			this.menuStrip1.SuspendLayout();
			this.customCellsContextMenuStrip.SuspendLayout();
			this.controlAppearanceContextMenuStrip.SuspendLayout();
			this.groupBox4.SuspendLayout();
			this.groupBox7.SuspendLayout();
			this.groupBox8.SuspendLayout();
			this.freezeToEdgesContextMenuStrip.SuspendLayout();
			this.groupBox9.SuspendLayout();
			this.groupBox10.SuspendLayout();
			this.SuspendLayout();
			// 
			// btnCalendarDoc
			// 
			resources.ApplyResources(this.btnCalendarDoc, "btnCalendarDoc");
			this.btnCalendarDoc.Name = "btnCalendarDoc";
			this.btnCalendarDoc.UseVisualStyleBackColor = true;
			this.btnCalendarDoc.Click += new System.EventHandler(this.button1_Click);
			// 
			// btnOrderDoc
			// 
			resources.ApplyResources(this.btnOrderDoc, "btnOrderDoc");
			this.btnOrderDoc.Name = "btnOrderDoc";
			this.btnOrderDoc.UseVisualStyleBackColor = true;
			this.btnOrderDoc.Click += new System.EventHandler(this.button2_Click);
			// 
			// btnProjectCostDoc
			// 
			resources.ApplyResources(this.btnProjectCostDoc, "btnProjectCostDoc");
			this.btnProjectCostDoc.Name = "btnProjectCostDoc";
			this.btnProjectCostDoc.UseVisualStyleBackColor = true;
			this.btnProjectCostDoc.Click += new System.EventHandler(this.button3_Click);
			// 
			// button4
			// 
			resources.ApplyResources(this.button4, "button4");
			this.button4.Name = "button4";
			this.button4.UseVisualStyleBackColor = true;
			this.button4.Click += new System.EventHandler(this.button4_Click);
			// 
			// button5
			// 
			resources.ApplyResources(this.button5, "button5");
			this.button5.Name = "button5";
			this.button5.UseVisualStyleBackColor = true;
			this.button5.Click += new System.EventHandler(this.button5_Click);
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.btnMazeDoc);
			this.groupBox1.Controls.Add(this.btnProjectCostDoc);
			this.groupBox1.Controls.Add(this.btnOrderDoc);
			this.groupBox1.Controls.Add(this.btnCalendarDoc);
			resources.ApplyResources(this.groupBox1, "groupBox1");
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.TabStop = false;
			// 
			// btnMazeDoc
			// 
			resources.ApplyResources(this.btnMazeDoc, "btnMazeDoc");
			this.btnMazeDoc.Name = "btnMazeDoc";
			this.btnMazeDoc.UseVisualStyleBackColor = true;
			this.btnMazeDoc.Click += new System.EventHandler(this.button9_Click);
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.btnCustomHeader);
			this.groupBox2.Controls.Add(this.btnMergedCells);
			this.groupBox2.Controls.Add(this.btnBorderStyles);
			this.groupBox2.Controls.Add(this.btnCellColors);
			resources.ApplyResources(this.groupBox2, "groupBox2");
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.TabStop = false;
			// 
			// btnCustomHeader
			// 
			resources.ApplyResources(this.btnCustomHeader, "btnCustomHeader");
			this.btnCustomHeader.Name = "btnCustomHeader";
			this.btnCustomHeader.UseVisualStyleBackColor = true;
			this.btnCustomHeader.Click += new System.EventHandler(this.btnCustomHeader_Click);
			// 
			// btnMergedCells
			// 
			resources.ApplyResources(this.btnMergedCells, "btnMergedCells");
			this.btnMergedCells.Name = "btnMergedCells";
			this.btnMergedCells.UseVisualStyleBackColor = true;
			this.btnMergedCells.Click += new System.EventHandler(this.button8_Click);
			// 
			// btnBorderStyles
			// 
			resources.ApplyResources(this.btnBorderStyles, "btnBorderStyles");
			this.btnBorderStyles.Name = "btnBorderStyles";
			this.btnBorderStyles.UseVisualStyleBackColor = true;
			this.btnBorderStyles.Click += new System.EventHandler(this.button7_Click);
			// 
			// btnCellColors
			// 
			resources.ApplyResources(this.btnCellColors, "btnCellColors");
			this.btnCellColors.Name = "btnCellColors";
			this.btnCellColors.UseVisualStyleBackColor = true;
			this.btnCellColors.Click += new System.EventHandler(this.button6_Click);
			// 
			// btnSelectionMode
			// 
			resources.ApplyResources(this.btnSelectionMode, "btnSelectionMode");
			this.btnSelectionMode.Name = "btnSelectionMode";
			this.btnSelectionMode.UseVisualStyleBackColor = true;
			this.btnSelectionMode.Click += new System.EventHandler(this.btnSelectionMode_Click);
			// 
			// groupBox3
			// 
			this.groupBox3.Controls.Add(this.btnCustomSelection);
			this.groupBox3.Controls.Add(this.btnMultisheet);
			this.groupBox3.Controls.Add(this.btnFilterAndSort);
			this.groupBox3.Controls.Add(this.button2);
			this.groupBox3.Controls.Add(this.btnSelectionMode);
			this.groupBox3.Controls.Add(this.button13);
			this.groupBox3.Controls.Add(this.button23);
			this.groupBox3.Controls.Add(this.button21);
			this.groupBox3.Controls.Add(this.btnDataFormat);
			this.groupBox3.Controls.Add(this.btnMergeCells);
			this.groupBox3.Controls.Add(this.btnAutoDataFormatDoc);
			this.groupBox3.Controls.Add(this.button4);
			resources.ApplyResources(this.groupBox3, "groupBox3");
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.TabStop = false;
			// 
			// btnCustomSelection
			// 
			resources.ApplyResources(this.btnCustomSelection, "btnCustomSelection");
			this.btnCustomSelection.Name = "btnCustomSelection";
			this.btnCustomSelection.UseVisualStyleBackColor = true;
			this.btnCustomSelection.Click += new System.EventHandler(this.btnCustomSelection_Click);
			// 
			// btnMultisheet
			// 
			resources.ApplyResources(this.btnMultisheet, "btnMultisheet");
			this.btnMultisheet.Name = "btnMultisheet";
			this.btnMultisheet.UseVisualStyleBackColor = true;
			this.btnMultisheet.Click += new System.EventHandler(this.btnMultisheet_Click);
			// 
			// btnFilterAndSort
			// 
			resources.ApplyResources(this.btnFilterAndSort, "btnFilterAndSort");
			this.btnFilterAndSort.Name = "btnFilterAndSort";
			this.btnFilterAndSort.UseVisualStyleBackColor = true;
			this.btnFilterAndSort.Click += new System.EventHandler(this.btnFilterAndSort_Click);
			// 
			// button2
			// 
			resources.ApplyResources(this.button2, "button2");
			this.button2.Name = "button2";
			this.button2.UseVisualStyleBackColor = true;
			this.button2.Click += new System.EventHandler(this.button2_Click_1);
			// 
			// button13
			// 
			resources.ApplyResources(this.button13, "button13");
			this.button13.Name = "button13";
			this.button13.UseVisualStyleBackColor = true;
			this.button13.Click += new System.EventHandler(this.button13_Click);
			// 
			// button23
			// 
			resources.ApplyResources(this.button23, "button23");
			this.button23.Name = "button23";
			this.button23.UseVisualStyleBackColor = true;
			this.button23.Click += new System.EventHandler(this.button23_Click);
			// 
			// button21
			// 
			resources.ApplyResources(this.button21, "button21");
			this.button21.Name = "button21";
			this.button21.UseVisualStyleBackColor = true;
			this.button21.Click += new System.EventHandler(this.button21_Click);
			// 
			// btnDataFormat
			// 
			resources.ApplyResources(this.btnDataFormat, "btnDataFormat");
			this.btnDataFormat.Name = "btnDataFormat";
			this.btnDataFormat.UseVisualStyleBackColor = true;
			this.btnDataFormat.Click += new System.EventHandler(this.button20_Click);
			// 
			// btnMergeCells
			// 
			resources.ApplyResources(this.btnMergeCells, "btnMergeCells");
			this.btnMergeCells.Name = "btnMergeCells";
			this.btnMergeCells.UseVisualStyleBackColor = true;
			this.btnMergeCells.Click += new System.EventHandler(this.btnMergeCells_Click);
			// 
			// btnAutoDataFormatDoc
			// 
			resources.ApplyResources(this.btnAutoDataFormatDoc, "btnAutoDataFormatDoc");
			this.btnAutoDataFormatDoc.Name = "btnAutoDataFormatDoc";
			this.btnAutoDataFormatDoc.UseVisualStyleBackColor = true;
			this.btnAutoDataFormatDoc.Click += new System.EventHandler(this.button10_Click);
			// 
			// button30
			// 
			resources.ApplyResources(this.button30, "button30");
			this.button30.Name = "button30";
			this.button30.UseVisualStyleBackColor = true;
			this.button30.Click += new System.EventHandler(this.button30_Click);
			// 
			// groupBox5
			// 
			this.groupBox5.Controls.Add(this.button26);
			this.groupBox5.Controls.Add(this.button19);
			this.groupBox5.Controls.Add(this.button16);
			this.groupBox5.Controls.Add(this.button14);
			resources.ApplyResources(this.groupBox5, "groupBox5");
			this.groupBox5.Name = "groupBox5";
			this.groupBox5.TabStop = false;
			// 
			// button26
			// 
			resources.ApplyResources(this.button26, "button26");
			this.button26.Name = "button26";
			this.button26.UseVisualStyleBackColor = true;
			this.button26.Click += new System.EventHandler(this.button26_Click);
			// 
			// button19
			// 
			resources.ApplyResources(this.button19, "button19");
			this.button19.Name = "button19";
			this.button19.UseVisualStyleBackColor = true;
			this.button19.Click += new System.EventHandler(this.button19_Click);
			// 
			// button16
			// 
			resources.ApplyResources(this.button16, "button16");
			this.button16.Name = "button16";
			this.button16.UseVisualStyleBackColor = true;
			this.button16.Click += new System.EventHandler(this.button16_Click);
			// 
			// button14
			// 
			resources.ApplyResources(this.button14, "button14");
			this.button14.Name = "button14";
			this.button14.UseVisualStyleBackColor = true;
			this.button14.Click += new System.EventHandler(this.button14_Click);
			// 
			// button15
			// 
			resources.ApplyResources(this.button15, "button15");
			this.button15.Name = "button15";
			this.button15.UseVisualStyleBackColor = true;
			this.button15.Click += new System.EventHandler(this.button15_Click);
			// 
			// groupBox6
			// 
			this.groupBox6.Controls.Add(this.button25);
			this.groupBox6.Controls.Add(this.btnCustomFunction);
			this.groupBox6.Controls.Add(this.button17);
			this.groupBox6.Controls.Add(this.button15);
			this.groupBox6.Controls.Add(this.button18);
			resources.ApplyResources(this.groupBox6, "groupBox6");
			this.groupBox6.Name = "groupBox6";
			this.groupBox6.TabStop = false;
			// 
			// button25
			// 
			resources.ApplyResources(this.button25, "button25");
			this.button25.Name = "button25";
			this.button25.UseVisualStyleBackColor = true;
			this.button25.Click += new System.EventHandler(this.button25_Click);
			// 
			// btnCustomFunction
			// 
			resources.ApplyResources(this.btnCustomFunction, "btnCustomFunction");
			this.btnCustomFunction.Name = "btnCustomFunction";
			this.btnCustomFunction.UseVisualStyleBackColor = true;
			this.btnCustomFunction.Click += new System.EventHandler(this.button24_Click);
			// 
			// button17
			// 
			resources.ApplyResources(this.button17, "button17");
			this.button17.Name = "button17";
			this.button17.UseVisualStyleBackColor = true;
			this.button17.Click += new System.EventHandler(this.button17_Click);
			// 
			// button18
			// 
			resources.ApplyResources(this.button18, "button18");
			this.button18.Name = "button18";
			this.button18.UseVisualStyleBackColor = true;
			this.button18.Click += new System.EventHandler(this.button18_Click);
			// 
			// button22
			// 
			this.button22.ForeColor = System.Drawing.Color.MidnightBlue;
			resources.ApplyResources(this.button22, "button22");
			this.button22.Name = "button22";
			this.button22.UseVisualStyleBackColor = true;
			this.button22.Click += new System.EventHandler(this.button22_Click);
			// 
			// menuStrip1
			// 
			this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.helpToolStripMenuItem});
			resources.ApplyResources(this.menuStrip1, "menuStrip1");
			this.menuStrip1.Name = "menuStrip1";
			// 
			// fileToolStripMenuItem
			// 
			this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.randomDemoToolStripMenuItem,
            this.toolStripMenuItem3,
            this.closeToolStripMenuItem});
			this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
			resources.ApplyResources(this.fileToolStripMenuItem, "fileToolStripMenuItem");
			// 
			// randomDemoToolStripMenuItem
			// 
			this.randomDemoToolStripMenuItem.Name = "randomDemoToolStripMenuItem";
			resources.ApplyResources(this.randomDemoToolStripMenuItem, "randomDemoToolStripMenuItem");
			this.randomDemoToolStripMenuItem.Click += new System.EventHandler(this.randomDemoToolStripMenuItem_Click);
			// 
			// toolStripMenuItem3
			// 
			this.toolStripMenuItem3.Name = "toolStripMenuItem3";
			resources.ApplyResources(this.toolStripMenuItem3, "toolStripMenuItem3");
			// 
			// closeToolStripMenuItem
			// 
			this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
			resources.ApplyResources(this.closeToolStripMenuItem, "closeToolStripMenuItem");
			this.closeToolStripMenuItem.Click += new System.EventHandler(this.closeToolStripMenuItem_Click);
			// 
			// helpToolStripMenuItem
			// 
			this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.reportBugToolStripMenuItem,
            this.toolStripMenuItem1,
            this.aboutToolStripMenuItem,
            this.projectHomepageToolStripMenuItem});
			this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
			resources.ApplyResources(this.helpToolStripMenuItem, "helpToolStripMenuItem");
			// 
			// reportBugToolStripMenuItem
			// 
			this.reportBugToolStripMenuItem.Name = "reportBugToolStripMenuItem";
			resources.ApplyResources(this.reportBugToolStripMenuItem, "reportBugToolStripMenuItem");
			this.reportBugToolStripMenuItem.Click += new System.EventHandler(this.reportBugToolStripMenuItem_Click);
			// 
			// toolStripMenuItem1
			// 
			this.toolStripMenuItem1.Name = "toolStripMenuItem1";
			resources.ApplyResources(this.toolStripMenuItem1, "toolStripMenuItem1");
			// 
			// aboutToolStripMenuItem
			// 
			this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
			resources.ApplyResources(this.aboutToolStripMenuItem, "aboutToolStripMenuItem");
			this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
			// 
			// projectHomepageToolStripMenuItem
			// 
			this.projectHomepageToolStripMenuItem.Name = "projectHomepageToolStripMenuItem";
			resources.ApplyResources(this.projectHomepageToolStripMenuItem, "projectHomepageToolStripMenuItem");
			this.projectHomepageToolStripMenuItem.Click += new System.EventHandler(this.projectHomepageToolStripMenuItem_Click);
			// 
			// customCellsContextMenuStrip
			// 
			this.customCellsContextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.numericProgressToolStripMenuItem,
            this.slideCellToolStripMenuItem});
			this.customCellsContextMenuStrip.Name = "customCellsContextMenuStrip";
			resources.ApplyResources(this.customCellsContextMenuStrip, "customCellsContextMenuStrip");
			// 
			// numericProgressToolStripMenuItem
			// 
			this.numericProgressToolStripMenuItem.Name = "numericProgressToolStripMenuItem";
			resources.ApplyResources(this.numericProgressToolStripMenuItem, "numericProgressToolStripMenuItem");
			this.numericProgressToolStripMenuItem.Click += new System.EventHandler(this.numericProgressToolStripMenuItem_Click);
			// 
			// slideCellToolStripMenuItem
			// 
			this.slideCellToolStripMenuItem.Name = "slideCellToolStripMenuItem";
			resources.ApplyResources(this.slideCellToolStripMenuItem, "slideCellToolStripMenuItem");
			this.slideCellToolStripMenuItem.Click += new System.EventHandler(this.slideCellToolStripMenuItem_Click);
			// 
			// controlAppearanceContextMenuStrip
			// 
			this.controlAppearanceContextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.goldSilverToolStripMenuItem,
            this.lightGreenToolStripMenuItem,
            this.snowWhiteToolStripMenuItem});
			this.controlAppearanceContextMenuStrip.Name = "customCellsContextMenuStrip";
			resources.ApplyResources(this.controlAppearanceContextMenuStrip, "controlAppearanceContextMenuStrip");
			// 
			// goldSilverToolStripMenuItem
			// 
			this.goldSilverToolStripMenuItem.Name = "goldSilverToolStripMenuItem";
			resources.ApplyResources(this.goldSilverToolStripMenuItem, "goldSilverToolStripMenuItem");
			this.goldSilverToolStripMenuItem.Click += new System.EventHandler(this.goldSilverToolStripMenuItem_Click);
			// 
			// lightGreenToolStripMenuItem
			// 
			this.lightGreenToolStripMenuItem.Name = "lightGreenToolStripMenuItem";
			resources.ApplyResources(this.lightGreenToolStripMenuItem, "lightGreenToolStripMenuItem");
			this.lightGreenToolStripMenuItem.Click += new System.EventHandler(this.lightGreenToolStripMenuItem_Click);
			// 
			// snowWhiteToolStripMenuItem
			// 
			this.snowWhiteToolStripMenuItem.Name = "snowWhiteToolStripMenuItem";
			resources.ApplyResources(this.snowWhiteToolStripMenuItem, "snowWhiteToolStripMenuItem");
			this.snowWhiteToolStripMenuItem.Click += new System.EventHandler(this.snowWhiteToolStripMenuItem_Click);
			// 
			// groupBox4
			// 
			this.groupBox4.Controls.Add(this.btnMaximumSheet);
			this.groupBox4.Controls.Add(this.button12);
			this.groupBox4.Controls.Add(this.btnManyRows);
			resources.ApplyResources(this.groupBox4, "groupBox4");
			this.groupBox4.Name = "groupBox4";
			this.groupBox4.TabStop = false;
			// 
			// btnMaximumSheet
			// 
			resources.ApplyResources(this.btnMaximumSheet, "btnMaximumSheet");
			this.btnMaximumSheet.Name = "btnMaximumSheet";
			this.btnMaximumSheet.UseVisualStyleBackColor = true;
			this.btnMaximumSheet.Click += new System.EventHandler(this.button32_Click);
			// 
			// button12
			// 
			resources.ApplyResources(this.button12, "button12");
			this.button12.Name = "button12";
			this.button12.UseVisualStyleBackColor = true;
			this.button12.Click += new System.EventHandler(this.button12_Click);
			// 
			// btnManyRows
			// 
			resources.ApplyResources(this.btnManyRows, "btnManyRows");
			this.btnManyRows.Name = "btnManyRows";
			this.btnManyRows.UseVisualStyleBackColor = true;
			this.btnManyRows.Click += new System.EventHandler(this.button11_Click);
			// 
			// groupBox7
			// 
			this.groupBox7.Controls.Add(this.btnCustomDropdown);
			this.groupBox7.Controls.Add(this.button34);
			this.groupBox7.Controls.Add(this.button33);
			this.groupBox7.Controls.Add(this.button31);
			this.groupBox7.Controls.Add(this.button29);
			this.groupBox7.Controls.Add(this.button27);
			resources.ApplyResources(this.groupBox7, "groupBox7");
			this.groupBox7.Name = "groupBox7";
			this.groupBox7.TabStop = false;
			// 
			// btnCustomDropdown
			// 
			resources.ApplyResources(this.btnCustomDropdown, "btnCustomDropdown");
			this.btnCustomDropdown.Name = "btnCustomDropdown";
			this.btnCustomDropdown.UseVisualStyleBackColor = true;
			this.btnCustomDropdown.Click += new System.EventHandler(this.btnCustomDropdown_Click);
			// 
			// button34
			// 
			resources.ApplyResources(this.button34, "button34");
			this.button34.Name = "button34";
			this.button34.UseVisualStyleBackColor = true;
			this.button34.Click += new System.EventHandler(this.button34_Click);
			// 
			// button33
			// 
			resources.ApplyResources(this.button33, "button33");
			this.button33.Name = "button33";
			this.button33.UseVisualStyleBackColor = true;
			this.button33.Click += new System.EventHandler(this.button33_Click);
			// 
			// button31
			// 
			resources.ApplyResources(this.button31, "button31");
			this.button31.Name = "button31";
			this.button31.UseVisualStyleBackColor = true;
			this.button31.Click += new System.EventHandler(this.button31_Click);
			// 
			// button29
			// 
			resources.ApplyResources(this.button29, "button29");
			this.button29.Name = "button29";
			this.button29.UseVisualStyleBackColor = true;
			this.button29.Click += new System.EventHandler(this.button29_Click);
			// 
			// button27
			// 
			resources.ApplyResources(this.button27, "button27");
			this.button27.Name = "button27";
			this.button27.UseVisualStyleBackColor = true;
			this.button27.Click += new System.EventHandler(this.button27_Click);
			// 
			// labVersion
			// 
			resources.ApplyResources(this.labVersion, "labVersion");
			this.labVersion.Name = "labVersion";
			// 
			// lnkReportBug
			// 
			resources.ApplyResources(this.lnkReportBug, "lnkReportBug");
			this.lnkReportBug.Name = "lnkReportBug";
			this.lnkReportBug.TabStop = true;
			this.lnkReportBug.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkReportBug_LinkClicked);
			// 
			// groupBox8
			// 
			this.groupBox8.Controls.Add(this.btnFreezeToEdges);
			this.groupBox8.Controls.Add(this.button5);
			this.groupBox8.Controls.Add(this.button30);
			resources.ApplyResources(this.groupBox8, "groupBox8");
			this.groupBox8.Name = "groupBox8";
			this.groupBox8.TabStop = false;
			// 
			// btnFreezeToEdges
			// 
			resources.ApplyResources(this.btnFreezeToEdges, "btnFreezeToEdges");
			this.btnFreezeToEdges.Name = "btnFreezeToEdges";
			this.btnFreezeToEdges.UseVisualStyleBackColor = true;
			this.btnFreezeToEdges.Click += new System.EventHandler(this.btnFreezeToEdges_Click);
			// 
			// freezeToEdgesContextMenuStrip
			// 
			this.freezeToEdgesContextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.freeToLeftToolStripMenuItem,
            this.freezeToTopToolStripMenuItem,
            this.freezeToRightToolStripMenuItem,
            this.freezeToBottomToolStripMenuItem,
            this.toolStripMenuItem2,
            this.freezeToLeftTopToolStripMenuItem,
            this.freezeToLeftBottomToolStripMenuItem,
            this.freezeToRightTopToolStripMenuItem,
            this.freezeToRightBottomToolStripMenuItem});
			this.freezeToEdgesContextMenuStrip.Name = "customCellsContextMenuStrip";
			resources.ApplyResources(this.freezeToEdgesContextMenuStrip, "freezeToEdgesContextMenuStrip");
			// 
			// freeToLeftToolStripMenuItem
			// 
			this.freeToLeftToolStripMenuItem.Name = "freeToLeftToolStripMenuItem";
			resources.ApplyResources(this.freeToLeftToolStripMenuItem, "freeToLeftToolStripMenuItem");
			this.freeToLeftToolStripMenuItem.Click += new System.EventHandler(this.freeToLeftToolStripMenuItem_Click);
			// 
			// freezeToTopToolStripMenuItem
			// 
			this.freezeToTopToolStripMenuItem.Name = "freezeToTopToolStripMenuItem";
			resources.ApplyResources(this.freezeToTopToolStripMenuItem, "freezeToTopToolStripMenuItem");
			this.freezeToTopToolStripMenuItem.Click += new System.EventHandler(this.freezeToTopToolStripMenuItem_Click);
			// 
			// freezeToRightToolStripMenuItem
			// 
			this.freezeToRightToolStripMenuItem.Name = "freezeToRightToolStripMenuItem";
			resources.ApplyResources(this.freezeToRightToolStripMenuItem, "freezeToRightToolStripMenuItem");
			this.freezeToRightToolStripMenuItem.Click += new System.EventHandler(this.freezeToRightToolStripMenuItem_Click);
			// 
			// freezeToBottomToolStripMenuItem
			// 
			this.freezeToBottomToolStripMenuItem.Name = "freezeToBottomToolStripMenuItem";
			resources.ApplyResources(this.freezeToBottomToolStripMenuItem, "freezeToBottomToolStripMenuItem");
			this.freezeToBottomToolStripMenuItem.Click += new System.EventHandler(this.freezeToBottomToolStripMenuItem_Click);
			// 
			// toolStripMenuItem2
			// 
			this.toolStripMenuItem2.Name = "toolStripMenuItem2";
			resources.ApplyResources(this.toolStripMenuItem2, "toolStripMenuItem2");
			// 
			// freezeToLeftTopToolStripMenuItem
			// 
			this.freezeToLeftTopToolStripMenuItem.Name = "freezeToLeftTopToolStripMenuItem";
			resources.ApplyResources(this.freezeToLeftTopToolStripMenuItem, "freezeToLeftTopToolStripMenuItem");
			this.freezeToLeftTopToolStripMenuItem.Click += new System.EventHandler(this.freezeToLeftTopToolStripMenuItem_Click);
			// 
			// freezeToLeftBottomToolStripMenuItem
			// 
			this.freezeToLeftBottomToolStripMenuItem.Name = "freezeToLeftBottomToolStripMenuItem";
			resources.ApplyResources(this.freezeToLeftBottomToolStripMenuItem, "freezeToLeftBottomToolStripMenuItem");
			this.freezeToLeftBottomToolStripMenuItem.Click += new System.EventHandler(this.freezeToLeftBottomToolStripMenuItem_Click);
			// 
			// freezeToRightTopToolStripMenuItem
			// 
			this.freezeToRightTopToolStripMenuItem.Name = "freezeToRightTopToolStripMenuItem";
			resources.ApplyResources(this.freezeToRightTopToolStripMenuItem, "freezeToRightTopToolStripMenuItem");
			this.freezeToRightTopToolStripMenuItem.Click += new System.EventHandler(this.freezeToRightTopToolStripMenuItem_Click);
			// 
			// freezeToRightBottomToolStripMenuItem
			// 
			this.freezeToRightBottomToolStripMenuItem.Name = "freezeToRightBottomToolStripMenuItem";
			resources.ApplyResources(this.freezeToRightBottomToolStripMenuItem, "freezeToRightBottomToolStripMenuItem");
			this.freezeToRightBottomToolStripMenuItem.Click += new System.EventHandler(this.freezeToRightBottomToolStripMenuItem_Click);
			// 
			// groupBox9
			// 
			this.groupBox9.Controls.Add(this.button35);
			this.groupBox9.Controls.Add(this.button38);
			resources.ApplyResources(this.groupBox9, "groupBox9");
			this.groupBox9.Name = "groupBox9";
			this.groupBox9.TabStop = false;
			// 
			// button35
			// 
			resources.ApplyResources(this.button35, "button35");
			this.button35.Name = "button35";
			this.button35.UseVisualStyleBackColor = true;
			this.button35.Click += new System.EventHandler(this.button35_Click);
			// 
			// button38
			// 
			resources.ApplyResources(this.button38, "button38");
			this.button38.Name = "button38";
			this.button38.UseVisualStyleBackColor = true;
			this.button38.Click += new System.EventHandler(this.button38_Click);
			// 
			// groupBox10
			// 
			this.groupBox10.Controls.Add(this.button36);
			this.groupBox10.Controls.Add(this.btnLoadExcel);
			resources.ApplyResources(this.groupBox10, "groupBox10");
			this.groupBox10.Name = "groupBox10";
			this.groupBox10.TabStop = false;
			// 
			// button36
			// 
			resources.ApplyResources(this.button36, "button36");
			this.button36.Name = "button36";
			this.button36.UseVisualStyleBackColor = true;
			// 
			// btnLoadExcel
			// 
			resources.ApplyResources(this.btnLoadExcel, "btnLoadExcel");
			this.btnLoadExcel.Name = "btnLoadExcel";
			this.btnLoadExcel.UseVisualStyleBackColor = true;
			this.btnLoadExcel.Click += new System.EventHandler(this.btnLoadExcel_Click);
			// 
			// dropdownButton1
			// 
			resources.ApplyResources(this.dropdownButton1, "dropdownButton1");
			this.dropdownButton1.Name = "dropdownButton1";
			this.dropdownButton1.UseVisualStyleBackColor = true;
			this.dropdownButton1.Click += new System.EventHandler(this.dropdownButton1_Click);
			// 
			// DemoForm
			// 
			resources.ApplyResources(this, "$this");
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.Controls.Add(this.groupBox10);
			this.Controls.Add(this.dropdownButton1);
			this.Controls.Add(this.groupBox8);
			this.Controls.Add(this.lnkReportBug);
			this.Controls.Add(this.labVersion);
			this.Controls.Add(this.groupBox7);
			this.Controls.Add(this.button22);
			this.Controls.Add(this.groupBox6);
			this.Controls.Add(this.groupBox5);
			this.Controls.Add(this.groupBox9);
			this.Controls.Add(this.groupBox4);
			this.Controls.Add(this.groupBox3);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.menuStrip1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MainMenuStrip = this.menuStrip1;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "DemoForm";
			this.Load += new System.EventHandler(this.DemoForm_Load);
			this.groupBox1.ResumeLayout(false);
			this.groupBox2.ResumeLayout(false);
			this.groupBox3.ResumeLayout(false);
			this.groupBox5.ResumeLayout(false);
			this.groupBox6.ResumeLayout(false);
			this.menuStrip1.ResumeLayout(false);
			this.menuStrip1.PerformLayout();
			this.customCellsContextMenuStrip.ResumeLayout(false);
			this.controlAppearanceContextMenuStrip.ResumeLayout(false);
			this.groupBox4.ResumeLayout(false);
			this.groupBox7.ResumeLayout(false);
			this.groupBox8.ResumeLayout(false);
			this.freezeToEdgesContextMenuStrip.ResumeLayout(false);
			this.groupBox9.ResumeLayout(false);
			this.groupBox10.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button btnCalendarDoc;
		private System.Windows.Forms.Button btnOrderDoc;
		private System.Windows.Forms.Button btnProjectCostDoc;
		private System.Windows.Forms.Button button4;
		private System.Windows.Forms.Button button5;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.Button btnMergedCells;
		private System.Windows.Forms.Button btnBorderStyles;
		private System.Windows.Forms.Button btnCellColors;
		private System.Windows.Forms.Button btnMazeDoc;
		private System.Windows.Forms.GroupBox groupBox3;
		private System.Windows.Forms.Button btnAutoDataFormatDoc;
		private System.Windows.Forms.GroupBox groupBox5;
		private System.Windows.Forms.Button button14;
		private System.Windows.Forms.Button button15;
		private System.Windows.Forms.Button button16;
		private System.Windows.Forms.Button btnMergeCells;
		private System.Windows.Forms.GroupBox groupBox6;
		private System.Windows.Forms.Button button17;
		private System.Windows.Forms.Button button18;
		private System.Windows.Forms.Button button21;
		private System.Windows.Forms.Button btnDataFormat;
		private System.Windows.Forms.Button button19;
		private System.Windows.Forms.Button button22;
		private System.Windows.Forms.MenuStrip menuStrip1;
		private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem projectHomepageToolStripMenuItem;
		private System.Windows.Forms.Button button23;
		private NewLabelButton btnCustomFunction;
		private System.Windows.Forms.Button button25;
		private System.Windows.Forms.Button button26;
		private DropdownButton button27;
		private System.Windows.Forms.ContextMenuStrip customCellsContextMenuStrip;
		private System.Windows.Forms.ToolStripMenuItem numericProgressToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem slideCellToolStripMenuItem;
		private System.Windows.Forms.ContextMenuStrip controlAppearanceContextMenuStrip;
		private System.Windows.Forms.ToolStripMenuItem goldSilverToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem lightGreenToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem snowWhiteToolStripMenuItem;
		private System.Windows.Forms.GroupBox groupBox4;
		private System.Windows.Forms.Button btnManyRows;
		private System.Windows.Forms.Button button12;
		private System.Windows.Forms.Button button13;
		private System.Windows.Forms.GroupBox groupBox7;
		private System.Windows.Forms.Button button29;
		private System.Windows.Forms.ToolStripMenuItem reportBugToolStripMenuItem;
		private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
		private System.Windows.Forms.Button button31;
		private System.Windows.Forms.Button button30;
		private System.Windows.Forms.Label labVersion;
		private System.Windows.Forms.LinkLabel lnkReportBug;
		private System.Windows.Forms.Button btnMaximumSheet;
		private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
		private System.Windows.Forms.Button button34;
		private System.Windows.Forms.Button button33;
		private System.Windows.Forms.GroupBox groupBox8;
		private DropdownButton btnFreezeToEdges;
		private System.Windows.Forms.ContextMenuStrip freezeToEdgesContextMenuStrip;
		private System.Windows.Forms.ToolStripMenuItem freeToLeftToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem freezeToTopToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem freezeToRightToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem freezeToBottomToolStripMenuItem;
		private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
		private System.Windows.Forms.ToolStripMenuItem freezeToLeftTopToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem freezeToLeftBottomToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem freezeToRightTopToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem freezeToRightBottomToolStripMenuItem;
		private System.Windows.Forms.GroupBox groupBox9;
		private System.Windows.Forms.Button button38;
		private System.Windows.Forms.Button button35;
		private System.Windows.Forms.Button btnSelectionMode;
		private DropdownButton dropdownButton1;
		private System.Windows.Forms.Button btnCustomHeader;
		private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
		private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
		private System.Windows.Forms.ToolStripMenuItem randomDemoToolStripMenuItem;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button btnFilterAndSort;
		private NewLabelButton btnMultisheet;
		private NewLabelButton btnCustomDropdown;
		private System.Windows.Forms.GroupBox groupBox10;
		private System.Windows.Forms.Button button36;
		private NewLabelButton btnLoadExcel;
		private NewLabelButton btnCustomSelection;
	}
}
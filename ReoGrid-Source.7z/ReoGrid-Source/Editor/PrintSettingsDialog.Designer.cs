﻿/*****************************************************************************
 * 
 * ReoGrid - .NET Spreadsheet Control
 * 
 * http://reogrid.net/
 *
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
 * KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
 * PURPOSE.
 *
 * ReoGridEditor released under BSD license.
 * 
 * Author: Jing Lu <lujing at unvell.com>
 * Copyright (c) 2012-2015 unvell.com, all rights reserved.
 * 
 ****************************************************************************/

namespace unvell.ReoGrid.Editor
{
	partial class PrintSettingsDialog
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.btnPaperSetup = new System.Windows.Forms.Button();
			this.txtPaperOrientation = new System.Windows.Forms.TextBox();
			this.txtPaperSize = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.numScale = new System.Windows.Forms.NumericUpDown();
			this.label4 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.btnOK = new System.Windows.Forms.Button();
			this.btnCancel = new System.Windows.Forms.Button();
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.rdoOverThenDown = new System.Windows.Forms.RadioButton();
			this.rdoDownThenOver = new System.Windows.Forms.RadioButton();
			this.groupBox1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.numScale)).BeginInit();
			this.groupBox3.SuspendLayout();
			this.SuspendLayout();
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.btnPaperSetup);
			this.groupBox1.Controls.Add(this.txtPaperOrientation);
			this.groupBox1.Controls.Add(this.txtPaperSize);
			this.groupBox1.Controls.Add(this.label2);
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Location = new System.Drawing.Point(12, 13);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(300, 124);
			this.groupBox1.TabIndex = 0;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Paper";
			// 
			// btnPaperSetup
			// 
			this.btnPaperSetup.Location = new System.Drawing.Point(208, 84);
			this.btnPaperSetup.Name = "btnPaperSetup";
			this.btnPaperSetup.Size = new System.Drawing.Size(75, 25);
			this.btnPaperSetup.TabIndex = 2;
			this.btnPaperSetup.Text = "Setup";
			this.btnPaperSetup.UseVisualStyleBackColor = true;
			this.btnPaperSetup.Click += new System.EventHandler(this.btnPaperSetup_Click);
			// 
			// txtPaperOrientation
			// 
			this.txtPaperOrientation.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtPaperOrientation.Location = new System.Drawing.Point(100, 59);
			this.txtPaperOrientation.Name = "txtPaperOrientation";
			this.txtPaperOrientation.ReadOnly = true;
			this.txtPaperOrientation.Size = new System.Drawing.Size(180, 13);
			this.txtPaperOrientation.TabIndex = 1;
			// 
			// txtPaperSize
			// 
			this.txtPaperSize.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtPaperSize.Location = new System.Drawing.Point(100, 31);
			this.txtPaperSize.Name = "txtPaperSize";
			this.txtPaperSize.ReadOnly = true;
			this.txtPaperSize.Size = new System.Drawing.Size(180, 13);
			this.txtPaperSize.TabIndex = 1;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(21, 59);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(61, 13);
			this.label2.TabIndex = 0;
			this.label2.Text = "Orientation:";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(21, 31);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(61, 13);
			this.label1.TabIndex = 0;
			this.label1.Text = "Paper Size:";
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.numScale);
			this.groupBox2.Controls.Add(this.label4);
			this.groupBox2.Controls.Add(this.label3);
			this.groupBox2.Location = new System.Drawing.Point(12, 229);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(300, 66);
			this.groupBox2.TabIndex = 0;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Scaling";
			// 
			// numScale
			// 
			this.numScale.Location = new System.Drawing.Point(94, 31);
			this.numScale.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
			this.numScale.Name = "numScale";
			this.numScale.Size = new System.Drawing.Size(56, 20);
			this.numScale.TabIndex = 1;
			this.numScale.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(160, 33);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(70, 13);
			this.label4.TabIndex = 0;
			this.label4.Text = "% normal size";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(32, 33);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(51, 13);
			this.label3.TabIndex = 0;
			this.label3.Text = "Adjust to ";
			// 
			// btnOK
			// 
			this.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.btnOK.Location = new System.Drawing.Point(324, 23);
			this.btnOK.Name = "btnOK";
			this.btnOK.Size = new System.Drawing.Size(75, 25);
			this.btnOK.TabIndex = 2;
			this.btnOK.Text = "OK";
			this.btnOK.UseVisualStyleBackColor = true;
			this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
			// 
			// btnCancel
			// 
			this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnCancel.Location = new System.Drawing.Point(324, 54);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(75, 25);
			this.btnCancel.TabIndex = 2;
			this.btnCancel.Text = "Cancel";
			this.btnCancel.UseVisualStyleBackColor = true;
			// 
			// groupBox3
			// 
			this.groupBox3.Controls.Add(this.rdoDownThenOver);
			this.groupBox3.Controls.Add(this.rdoOverThenDown);
			this.groupBox3.Location = new System.Drawing.Point(12, 143);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(300, 80);
			this.groupBox3.TabIndex = 2;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "Paging Order";
			// 
			// rdoOverThenDown
			// 
			this.rdoOverThenDown.AutoSize = true;
			this.rdoOverThenDown.Location = new System.Drawing.Point(163, 38);
			this.rdoOverThenDown.Name = "rdoOverThenDown";
			this.rdoOverThenDown.Size = new System.Drawing.Size(104, 17);
			this.rdoOverThenDown.TabIndex = 0;
			this.rdoOverThenDown.TabStop = true;
			this.rdoOverThenDown.Text = "Over, then down";
			this.rdoOverThenDown.UseVisualStyleBackColor = true;
			// 
			// rdoDownThenOver
			// 
			this.rdoDownThenOver.AutoSize = true;
			this.rdoDownThenOver.Location = new System.Drawing.Point(35, 38);
			this.rdoDownThenOver.Name = "rdoDownThenOver";
			this.rdoDownThenOver.Size = new System.Drawing.Size(104, 17);
			this.rdoDownThenOver.TabIndex = 0;
			this.rdoDownThenOver.TabStop = true;
			this.rdoDownThenOver.Text = "Down, then over";
			this.rdoDownThenOver.UseVisualStyleBackColor = true;
			// 
			// PrintSettingsDialog
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.CancelButton = this.btnCancel;
			this.ClientSize = new System.Drawing.Size(411, 307);
			this.ControlBox = false;
			this.Controls.Add(this.groupBox3);
			this.Controls.Add(this.btnCancel);
			this.Controls.Add(this.btnOK);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.groupBox1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "PrintSettingsDialog";
			this.Text = "Print Settings";
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.groupBox2.ResumeLayout(false);
			this.groupBox2.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.numScale)).EndInit();
			this.groupBox3.ResumeLayout(false);
			this.groupBox3.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Button btnPaperSetup;
		private System.Windows.Forms.TextBox txtPaperOrientation;
		private System.Windows.Forms.TextBox txtPaperSize;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.NumericUpDown numScale;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Button btnOK;
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.GroupBox groupBox3;
		private System.Windows.Forms.RadioButton rdoDownThenOver;
		private System.Windows.Forms.RadioButton rdoOverThenDown;
	}
}